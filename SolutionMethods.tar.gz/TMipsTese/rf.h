#include <ilopl/iloopl.h>
#include <iostream>
#include <vector>
#include <algorithm>    // std::sort
#include <cmath>
#include "mtrand.h"
#include <time.h> 

const char* tab = "\t";

IloNum startTime, TL, TIS;
IloNumArray incY, incYv;
IloBool hasInc = IloFalse;
MTRand_int32 irand;
IloBool rootHeur = IloFalse;

int THREADS;
int TRELIM;

IloBool isRand = IloFalse;


#define Erro 1e-4
#define maxIt 10000
#define maxItSmall 100
//#define geraLP
#define optRF


void startTimer(IloOplModel opl);
IloNum ActTime(IloOplModel opl);
void printSolution(ostream* outFO, ostream* outSol, IloOplModel opl, bool isRelax);
void subperiodPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void subperiodMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void backSubperiodPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void backSubperiodMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void productPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays);
void productMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays);
bool pairCompare(const std::pair<int, float>& firstElem, const std::pair<int, float>& secondElem) ;
void orderedProductPartY(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays);
void orderedProductMachinePartY(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays);
void subperiodPartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void EdgestoMiddlePartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void MiddletoEdgesPartYv(IloEnv env, IloOplModel opl, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void backSubperiodPartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays);
void saveSolRel(IloCplex cplex, IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray);
void saveSolRel(IloCplex cplex, IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray, IloInt soln);
void integra(IloModel model, IloExtractableArray convArray, IloIntArray partArray);
void fixa(IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray);
bool subfeasPump(IloEnv env, IloOplModel opl, IloIntVarArray vars, IloNumArray vals);
int RF(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30], IloInt partDig, IloInt TVS, IloInt TVF, IloInt partPM, IloInt TS, IloInt TF, IloNum alfa);
int RF_SP(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloInt partPM, IloInt TS, IloInt TF, IloInt partDig, IloInt TVS, IloInt TVF);
int RF_FP(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloInt part, IloInt TS, IloInt TF);
int LP_and_fix(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv);
int feasPump(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv);
int FPRL(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloNum teta);
int RCH(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30]);
void generateSequence(IloEnv env, IloOplModel opl, IloArray< IloIntArray > Sequences, IloInt l, IloInt M,IloInt N);
void calcDemand(IloEnv env, IloOplModel opl, IloInt pi, IloInt N, IloInt M, IloInt T, IloInt S, IloIntArray Ybar, IloNumArray D);
int FBCH(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30], IloNum teta);
int LP(IloOplModel opl);
int FO(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, ostream* output, char paramName[30], IloInt partPM, IloInt TS, IloInt TF, IloNum alfa, IloNum beta);
int main(int argc, char* argv[]);
