#include "rf.h"

ILOMIPINFOCALLBACK1(printCallback,ostream*, output) {
	*output << fixed << setprecision(4) << getIncumbentObjValue() << tab << getBestObjValue() << tab << getCplexTime()-getStartTime() <<  std::endl;
}

void roundHeuristic(IloEnv env, IloOplModel opl, IloIntArray partY, IloIntVarArray Y, IloNumArray incX, int S, int M, int N){
	if(rootHeur)
		return;

	rootHeur = IloTrue;
	//std::cout << partY << std::endl;

	IloNumArray incY(env);
	incY.setSize(incX.getSize());
	vector<double> Roleta;
	Roleta.resize(N);
	double soma;
	IloCplex cplex = opl.getCplex();

	for(int aux=0;aux<incY.getSize();aux++)
		incY[aux]=0.0;

	for(int m=0;m<M;m++){
		for(int s=0;s<S;s++){
			soma=0;
			for(int j=0;j<N;j++){
				soma=soma+incX[j*S*M+s*M+m];
				Roleta[j]=soma;
			}
			for(int j=0;j<N;j++)
				if(soma>Erro)
					Roleta[j]=Roleta[j]/soma*10000;
				else
					Roleta[j]=(j+1)/N*10000;
			int rand=irand()%10000;
			int k=0;
			while(Roleta[k]<rand) k++;
			incY[k*S*M+s*M+m]=1.0;
		}
	}

	for(int i=0;i<partY.getSize();i++){
		if(incY[partY[i]]>0.5)
			Y[partY[i]].setBounds(1,1);
		else
			Y[partY[i]].setBounds(0,0);
	}

	std::cout << "Inicia resolu��o" << std::endl;
	cplex.solve();
	std::cout << "Termina resolu��o" << std::endl;
	getchar();
/*
	IloNumArray vals(env);
	IloIntVarArray vars(env);

	for(int i=0;i<partY.getSize();i++){
		vars.add(Y[partY[i]]);
		vals.add(incY[partY[i]]);
	}

	if(cplex.getNMIPStarts()>0)
		cplex.deleteMIPStarts(0,cplex.getNMIPStarts());
	cplex.addMIPStart(vars.toNumVarArray(),vals,IloCplex::MIPStartEffort::MIPStartSolveFixed);
*/
}
void startTimer(IloOplModel opl){
	startTime = opl.getCplex().getCplexTime();
}
IloNum ActTime(IloOplModel opl){
	return opl.getCplex().getCplexTime() - startTime;
}
void printSolution(ostream* outFO, ostream* outSol, IloOplModel opl, bool isRelax){
	IloNum FO=opl.getElement("f").asNum();
	IloNum LB=IloMax(opl.getCplex().getBestObjValue(),0);
	*outFO << fixed << setprecision(2) << FO << tab << LB << tab << ActTime(opl) << tab;
	for(int t=0; t<=opl.getElement("NParc").asInt(); t++)
		*outFO << opl.getElement("Parc").asNumMap().get((IloInt)t) << tab;
	if(isRand)
		*outFO << "R";
	*outFO << std::endl;
	if(!isRelax){
		IloIntMap Y_opl(opl.getElement("Y").asIntMap());
		IloNumMap X_opl(opl.getElement("X").asNumMap());
		IloIntMap Yv_opl(opl.getElement("Yv").asIntMap());
		IloNumMap Nhour_opl(opl.getElement("Nhour").asNumMap());
		IloNumMap Xdig_opl(opl.getElement("Xdig").asNumMap());
		IloNumMap Ivirg_opl(opl.getElement("Ivirg").asNumMap());
		IloNumMap Oliquor_opl(opl.getElement("Oliquor").asNumMap());
		IloNumMap Xliquor_opl(opl.getElement("Xliquor").asNumMap());
		IloNumMap Iliquor_opl(opl.getElement("Iliquor").asNumMap());
		IloNumMap Ovirg_opl(opl.getElement("Ovirg").asNumMap());
		IloNumMap Odry_opl(opl.getElement("Odry").asNumMap());
		IloNumMap Xdry_opl(opl.getElement("Xdry").asNumMap());
		IloNumMap Idry_opl(opl.getElement("Idry").asNumMap());
		IloNumMap XOdry_opl(opl.getElement("XOdry").asNumMap());
		IloNumMap Oheat_opl(opl.getElement("Oheat").asNumMap());
		IloNumMap Speeds_opl(opl.getElement("Speeds").asNumMap());
		IloIntMap grammage_Inicial_opl(opl.getElement("grammage_Inicial").asIntMap());
		IloNum speed_Inicial_opl(opl.getElement("speed_Inicial").asNum());
		IloNum I0_virg_opl(opl.getElement("I0_virg").asNum());
		IloNum I0_liquor_opl(opl.getElement("I0_liquor").asNum());
		IloNum I0_dry_opl(opl.getElement("I0_dry").asNum());
		IloNumMap IG_opl(opl.getElement("IG").asNumMap());
		IloNumMap IGBacklog_opl(opl.getElement("IGBacklog").asNumMap());
		IloSymbolMap NomesGrammage_opl(opl.getElement("NomesGrammage").asSymbolMap());
    
		IloInt NPMachines = opl.getElement("NPMachines").asInt();
		IloInt NGrammage = opl.getElement("NGrammage").asInt();
		IloInt T = opl.getElement("NPeriods").asInt();
		IloInt S = opl.getElement("NSubPeriods").asInt();
		IloInt NSpeed = opl.getElement("NSpeed").asInt();

		*outSol << "SubPeriod\tNHour\tDigestorProduction\tDigestorStockPulp\t";
		for(IloInt m=1;m<=NPMachines;m++)
			*outSol << "UtilizationVirgPulp\tGrammage\tGrammageProduction\t";
		*outSol << "Speed\tXliq\tOliq\tIliq\tXdry\tOdry\tIdry\tXOdry\tOheat\tInventory in Grammage\tBacklogging in Grammage" << std::endl;
		*outSol << "0\t0\t0\t" << I0_virg_opl << tab;
		for(IloInt m=1;m<=NPMachines;m++)
			*outSol << "0\t" << grammage_Inicial_opl.get(m) << "\t0\t";
		*outSol << "0\t0\t0\t" << I0_liquor_opl << "\t0\t0\t" << I0_dry_opl << "\t0\t0\t";
		IloNum Atrasos=0;
		for(IloInt j=1;j<=NGrammage;j++)
			Atrasos+=opl.getElement("Atrasos").asNumMap().get(j);
		*outSol << "0\t" << Atrasos << std::endl;
		for(IloInt s=1;s<=T*S;s++){
			*outSol << s << tab;
			*outSol << Nhour_opl.get(s) << tab;                  
			*outSol << Xdig_opl.get(s) << tab;                  
			*outSol << Ivirg_opl.get(s) << tab;                  
			for(IloInt m=1;m<=NPMachines;m++){
				*outSol << Ovirg_opl[s].get(m) << tab;
				for (IloInt j=1;j<=NGrammage;j++)
					if(Y_opl[j][s].get(m))
						*outSol << j << tab;
				for(IloInt j=1;j<=NGrammage;j++)
					if(Y_opl[j][s].get(m))
						*outSol << X_opl[j][s].get(m) << tab;
			}
			for (IloInt v=1;v<=NSpeed;v++)
				if(Yv_opl[v].get(s))
					*outSol << Speeds_opl.get(v) << tab;
			*outSol << Xliquor_opl.get(s) << tab;                  
			*outSol << Oliquor_opl.get(s) << tab;                  
			*outSol << Iliquor_opl.get(s) << tab;
			*outSol << Xdry_opl.get(s) << tab;
			*outSol << Odry_opl.get(s) << tab;
			*outSol << Idry_opl.get(s) << tab;
			*outSol << XOdry_opl.get(s) << tab;
			*outSol << Oheat_opl.get(s) << tab;                  
			if(s<=T){
				IloNum StockTotal=0;
				for(IloInt j=1;j<=NGrammage;j++) 
					StockTotal+=IG_opl[j].get(s);
				*outSol << StockTotal << tab;
				IloNum BacklogTotal=0;
				for(IloInt j=1;j<=NGrammage;j++)
					BacklogTotal+=IGBacklog_opl[j].get(s);
				*outSol << BacklogTotal << tab;
			}
			*outSol << std::endl;
		}
		opl.printSolution(*outSol);
	}else{
		IloNumVarMap Xdig = opl.getElement("Xdig").asNumVarMap();
		IloIntVarMap Y = opl.getElement("Y").asIntVarMap();
		IloNumVarArray Z = opl.getElement("Z").asNumVarMap().asNewNumVarArray();
		IloNumVarMap X = opl.getElement("X").asNumVarMap();
		IloNumVarMap Iv = opl.getElement("Ivirg").asNumVarMap();
		IloNumVarMap IG = opl.getElement("IG").asNumVarMap();
		IloNumVarMap IGB = opl.getElement("IGBacklog").asNumVarMap();
		IloCplex cplex = opl.getCplex();
		IloInt M = opl.getElement("NPMachines").asInt();
		IloInt N = opl.getElement("NGrammage").asInt();
		IloInt T = opl.getElement("NPeriods").asInt();
		IloInt S = opl.getElement("NSubPeriods").asInt();
		IloInt V = opl.getElement("NSpeed").asInt();
		*outSol << fixed << setprecision(2) << right;
		*outSol << "Xdig" <<std::endl;
		for(IloInt t=1;t<=T*S;t++)
			*outSol << cplex.getValue(Xdig.get(t)) << " ";
		*outSol << std::endl << std::endl;
		for(IloInt m=1;m<=M;m++){
			*outSol << "Y m" << m << std::endl;
			for(IloInt i=1;i<=N;i++){
				for(IloInt t=1;t<=T*S;t++)
					*outSol << cplex.getValue(Y[i][t].get(m)) << " ";
				*outSol << std::endl;
			}
			*outSol << std::endl << std::endl;
		}
		for(IloInt m=1;m<=M;m++){
			*outSol << "X m" << m << std::endl;
			for(IloInt i=1;i<=N;i++){
				for(IloInt t=1;t<=T*S;t++)
					*outSol << cplex.getValue(X[i][t].get(m)) << " ";
				*outSol << std::endl;
			}
			*outSol << std::endl << std::endl;
		}
		*outSol << "Iv" << std::endl;
		for(IloInt t=1;t<=S*T;t++)
			*outSol << cplex.getValue(Iv.get(t)) << " ";
		*outSol << std::endl;


		*outSol << "I+" << std::endl;
		for(IloInt i=1;i<=N;i++){
			for(IloInt t=1;t<=T;t++)
				*outSol << cplex.getValue(IG[i].get(t)) << " ";
			*outSol << std::endl;
		}
		*outSol << std::endl;

		*outSol << "I-" << std::endl;
		for(IloInt i=1;i<=N;i++){
			for(IloInt t=1;t<=T;t++)
				*outSol << cplex.getValue(IGB[i].get(t)) << " ";
			*outSol << std::endl;
		}
		*outSol << std::endl;

		*outSol << "Z" << std::endl;
		for(IloInt i=0;i<Z.getSize();i++)
			*outSol << cplex.getValue(Z[i]) << " ";
		*outSol << std::endl;


	}
}
void subperiodPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt S0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int i=0;i<N;i++)
		for(int s=0;s<Size0;s++)
			for(int m=0;m<M;m++)
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
	S0 = Size0;
	p++;
	while(S0<T*S){
		PartArrays.add(IloIntArray(env));
		for(int i=0;i<N;i++)
			for(int s=S0; s<IloMin(S0+Size,T*S);s++)
				for(int m=0;m<M;m++)
					PartArrays[p].add(i*(T*S*M)+s*(M)+m);
		p++;
		S0 += Size;
	}
}
void subperiodMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt S0;
	IloInt p = PartArrays.getSize();
	IloBool addPart = IloTrue;
	for(int m=0;m<M;m++){
		if(addPart)
			PartArrays.add(IloIntArray(env));
		for(int i=0;i<N;i++)
			for(int s=0;s<Size0;s++)
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
		S0 = Size0;
		p++;
		while(S0<T*S){
			PartArrays.add(IloIntArray(env));
			for(int i=0;i<N;i++)
				for(int s=S0; s<IloMin(S0+Size,T*S);s++)
					PartArrays[p].add(i*(T*S*M)+s*(M)+m);
			p++;
			S0 += Size;
		}
		if(S0>T*S){
			Size0 = S0 - T*S;
			addPart = IloFalse;
			p--;
		}else{
			Size0 = Size;
			addPart = IloTrue;
		}
	}
}
void backSubperiodPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt S0=S*T;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int i=0;i<N;i++)
		for(int s=S0-Size0;s<S0;s++)
			for(int m=0;m<M;m++)
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
	S0 -= Size0;
	p++;
	while(S0>0){
		PartArrays.add(IloIntArray(env));
		for(int i=0;i<N;i++)
			for(int s=IloMax(S0-Size,0);s<S0;s++)
				for(int m=0;m<M;m++)
					PartArrays[p].add(i*(T*S*M)+s*(M)+m);
		p++;
		S0 -= Size;
	}
}
void backSubperiodMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt p = PartArrays.getSize();
	IloBool addPart = IloTrue;
	for(int m=0;m<M;m++){
		IloInt S0=S*T;
		if(addPart)
			PartArrays.add(IloIntArray(env));
		for(int i=0;i<N;i++)
			for(int s=S0-Size0;s<S0;s++)
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
		S0 -= Size0;
		p++;
		while(S0>0){
			PartArrays.add(IloIntArray(env));
			for(int i=0;i<N;i++)
				for(int s=IloMax(S0-Size,0);s<S0;s++)
					PartArrays[p].add(i*(T*S*M)+s*(M)+m);
			p++;
			S0 -= Size;
		}
		if(S0<0){
			Size0 = -S0;
			addPart = IloFalse;
			p--;
		}else{
			Size0 = Size;
			addPart = IloTrue;
		}
	}
}
void productPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays){
	IloInt N0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int i=0;i<Size0;i++)
		for(int s=0;s<S*T;s++)
			for(int m=0;m<M;m++){
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
			}
	N0 = Size0;
	p++;
	while(N0<N){
		PartArrays.add(IloIntArray(env));
		for(int i=N0;i<N0+Size && i<N;i++)
			for(int s=0; s<T*S;s++)
				for(int m=0;m<M;m++){
					PartArrays[p].add(i*(T*S*M)+s*(M)+m);
				}
		p++;
		N0 += Size;
	}
}
void productMachinePartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays){
	IloInt N0;
	IloInt p = PartArrays.getSize();
	IloBool addPart = IloTrue;
	for(int m=0;m<M;m++){
		if(addPart)
			PartArrays.add(IloIntArray(env));
		for(int i=0;i<Size0;i++)
			for(int s=0;s<S*T;s++)
				PartArrays[p].add(i*(T*S*M)+s*(M)+m);
		p++;
		N0 = Size0;
		while(N0<N){
			PartArrays.add(IloIntArray(env));
			for(int i=N0;i<IloMin(N0+Size,N);i++)
				for(int s=0; s<T*S;s++)
						PartArrays[p].add(i*(T*S*M)+s*(M)+m);
			p++;
			N0 += Size;
		}
		if(N0>N){
			Size0 = N0 - N;
			addPart = IloFalse;
			p--;
		}else{
			Size0 = Size;
			addPart = IloTrue;
		}
	}
}
void FOPartY(IloEnv env, IloInt N, IloInt M, IloInt T, IloInt S, IloInt TF, IloInt TS, IloInt NF, IloInt NS, IloInt MF, IloInt MS, IloArray< IloIntArray > PartArrays){
	IloInt S0;
	IloInt N0;
	IloInt M0;
	IloInt p = PartArrays.getSize();
	M0=0;
	while(M0<M){
		S0=0;
		while(S0<S*T){
			N0=0;
			while(N0<N){
				PartArrays.add(IloIntArray(env));
				for(int i=0;i<NF+NS;i++){
					for(int s=0;s<TF+TS;s++){
						for(int m=0;m<MF+MS;m++){
//							cout << p << tab << (i+N0)%N << tab << (s+S0)%(S*T) << tab << (m+M0)%M << endl;
							PartArrays[p].add((i+N0)%N*(T*S*M)+(s+S0)%(S*T)*(M)+(m+M0)%M);
						}
					}
				}
				N0 += NF;
				p++;
//				getchar();
			}
			S0 += TF;
		}
		M0 += MF;
	}
//	getchar();
}
bool pairCompare(const std::pair<int, float>& firstElem, const std::pair<int, float>& secondElem) {
  return firstElem.second > secondElem.second;
}
void orderedProductPartY(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays){
	IloNumMap prices = opl.getElement("price").asNumMap();
	std::vector< std::pair<int,float> > orderedItens;
	for(IloInt i=0;i<prices.getSize();i++)
		orderedItens.push_back(std::pair<int,float>(i,prices.get(i+1)));
	std::sort(orderedItens.begin(),orderedItens.end(),pairCompare);
//	for(IloInt i=0;i<prices.getSize();i++)
//		std::cout << orderedItens[i].first << tab << orderedItens[i].second << std::endl;

	IloInt N0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int i=0;i<Size0;i++){
		for(int s=0;s<S*T;s++)
			for(int m=0;m<M;m++){
				PartArrays[p].add(orderedItens[i].first*(T*S*M)+s*(M)+m);
			}
	}
	N0 = Size0;
	p++;
	while(N0<N){
		PartArrays.add(IloIntArray(env));
		for(int i=N0;i<IloMin(N0+Size,N);i++){
			for(int s=0; s<T*S;s++)
				for(int m=0;m<M;m++)
					PartArrays[p].add(orderedItens[i].first*(T*S*M)+s*(M)+m);
		}
		p++;
		N0 += Size;
	}
}
void orderedProductMachinePartY(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt Size0, IloInt Size, IloArray< IloIntArray > PartArrays){
	IloNumMap prices = opl.getElement("price").asNumMap();
	std::vector< std::pair<int,float> > orderedItens;
	for(IloInt i=0;i<prices.getSize();i++)
		orderedItens.push_back(std::pair<int,float>(i,prices.get(i+1)));
	std::sort(orderedItens.begin(),orderedItens.end(),pairCompare);
	for(IloInt i=0;i<prices.getSize();i++)
		std::cout << orderedItens[i].first << tab << orderedItens[i].second << tab << orderedItens[i].first*(T*S*M) << tab << orderedItens[i].first*(T*S*M)+(T*S-1)*M << tab << orderedItens[i].first*(T*S*M)+1 << tab << orderedItens[i].first*(T*S*M)+(T*S-1)*M+1 << std::endl;

	IloInt N0;
	IloInt p = PartArrays.getSize();
	IloBool addPart = IloTrue;
	for(int m=0;m<M;m++){
		if(addPart)
			PartArrays.add(IloIntArray(env));
		for(int i=0;i<Size0;i++)
			for(int s=0;s<S*T;s++)
				PartArrays[p].add(orderedItens[i].first*(T*S*M)+s*(M)+m);
		p++;
		N0 = Size0;
		while(N0<N){
			PartArrays.add(IloIntArray(env));
			for(int i=N0;i<IloMin(N0+Size,N);i++)
				for(int s=0; s<T*S;s++)
					PartArrays[p].add(orderedItens[i].first*(T*S*M)+s*(M)+m);
			N0 += Size;
			if(N0<=N)
				p++;
		}
		if(N0>N){
			Size0 = N0-N;
			addPart = IloFalse;
			p--;
		}else{
			Size0 = Size;
			addPart = IloTrue;
		}

	}
}
void subperiodPartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt S0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int v=0;v<V;v++)
		for(int s=0;s<Size0;s++)
			PartArrays[p].add(v*(T*S)+s);
	S0 = Size0;
	p++;
	while(S0<T*S){
		PartArrays.add(IloIntArray(env));
		for(int v=0;v<V;v++)
			for(int s=S0;s<IloMin(S0+Size,T*S);s++)
				PartArrays[p].add(v*(T*S)+s);
		p++;
		S0 += Size;
	}
}
void EdgestoMiddlePartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt downV = V;
	IloInt upV = 0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(IloInt v=upV;v<upV+Size0 && v <V;v++)
		for(int s=0;s<T*S;s++)
			PartArrays[p].add(v*(T*S)+s);
	for(IloInt v=downV-1;v>=downV-Size0 && v>=0;v--)
		for(int s=0;s<T*S;s++)
			PartArrays[p].add(v*(T*S)+s);
	upV = Size0;
	downV = V - Size0;
	p++;
	while(upV<downV){
		PartArrays.add(IloIntArray(env));
		for(IloInt v=upV;v<upV+Size && v <V;v++)
			for(int s=0;s<T*S;s++)
				PartArrays[p].add(v*(T*S)+s);
		for(IloInt v=downV-1;v>=downV-Size && v>=0;v--)
			for(int s=0;s<T*S;s++)
				PartArrays[p].add(v*(T*S)+s);
		p++;
		downV -= Size;
		upV += Size;
	}
}
void MiddletoEdgesPartYv(IloEnv env, IloOplModel opl, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt upV;
	IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
	IloNum Speed0 = opl.getElement("speed_Inicial").asNum();
	for(IloInt v=1;v<=Speeds.getSize();v++)
		if(Speeds.get(v) == Speed0){
			upV = v-1;
			break;
		}
	IloInt downV = upV;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(IloInt v=downV-1;v>=downV-Size0 && v>=0;v--){
		cout << v << tab;
		for(IloInt s=0;s<T*S;s++){
			PartArrays[p].add(v*(T*S)+s);
		}
	}
	for(IloInt v=upV;v<upV+Size0 && v<V;v++){
		cout << v << tab;
		for(IloInt s=0;s<T*S;s++){
			PartArrays[p].add(v*(T*S)+s);
		}
	}
	cout << endl;
	upV += Size0;
	downV -= Size0;
	p++;
	while(upV < V || downV >= 0){
		PartArrays.add(IloIntArray(env));
		if(upV<V){
			for(IloInt v=upV;v<upV+Size && v<V;v++){
				cout << v << tab;
				for(IloInt s=0;s<T*S;s++){
					PartArrays[p].add(v*(T*S)+s);
				}
			}
			upV = IloMin(upV + Size,V);
		}
		if(downV>=0){
			for(IloInt v=downV-1;v>=downV-Size && v>=0;v--){
				cout << v << tab;
				for(IloInt s=0;s<T*S;s++){
					PartArrays[p].add(v*(T*S)+s);
				}
			}
			downV = IloMax(downV - Size,-1);
		}
		p++;
		cout << endl;
	}
}
void backSubperiodPartYv(IloEnv env, IloInt V, IloInt T, IloInt S, IloInt Size0, IloInt Size,IloArray< IloIntArray > PartArrays){
	IloInt S0;
	IloInt p = PartArrays.getSize();
	PartArrays.add(IloIntArray(env));
	for(int v=0;v<V;v++)
		for(int s=0;s<Size0;s++)
			PartArrays[p].add(v*(T*S)+s);
	S0 = Size0;
	p++;
	while(S0<T*S){
		PartArrays.add(IloIntArray(env));
		for(int v=0;v<V;v++)
			for(int s=S0;s<IloMin(S0+Size,T*S);s++)
				PartArrays[p].add(v*(T*S)+s);
		p++;
		S0 += Size;
	}
}
void saveSolRel(IloCplex cplex, IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray){
	for(int i=0;i<partArray.getSize();i++)
		valsArray[i] = cplex.getValue(varArray[partArray[i]]);
}
void saveSolRel(IloCplex cplex, IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray, IloInt soln){
	for(int i=0;i<partArray.getSize();i++)
		valsArray[i] = cplex.getValue(varArray[partArray[i]],soln);
}
void integra(IloModel model, IloExtractableArray convArray, IloIntArray partArray){
	for(int i=0;i<partArray.getSize();i++){
		model.remove(convArray[partArray[i]]);
	}
}
void relaxa(IloModel model, IloExtractableArray convArray, IloIntArray partArray){
	for(int i=0;i<partArray.getSize();i++){
		model.add(convArray[partArray[i]]);
	}
}
void fixa(IloIntVarArray varArray, IloNumArray valsArray, IloIntArray partArray){
	for(int i=0;i<partArray.getSize();i++)
		if(valsArray[partArray[i]]<0.5)
			varArray[partArray[i]].setBounds(0,0);
		else
			varArray[partArray[i]].setBounds(1,1);
}
void libera(IloIntVarArray varArray, IloIntArray partArray){
	for(int i=0;i<partArray.getSize();i++)
		varArray[partArray[i]].setBounds(0,1);
}
bool subfeasPump(IloEnv env, IloOplModel opl, IloIntVarArray vars, IloNumArray vals){
	
	IloNum alfa = 0.8;
	IloModel model = opl.getModel();
	IloCplex cplex = opl.getCplex();
	IloExpr deltaY(env);
	for(int i=0; i<vars.getSize(); i++)
		if(vals[i]<alfa)
			deltaY += vars[i];
		else
			deltaY += (1 - vars[i]);

	IloObjective oldObj = opl.getObjective();
	IloObjective newObj = IloMinimize(env,deltaY);

	model.remove(oldObj);
	model.add(newObj);
	if(!cplex.solve())
			return false;
	
	cplex.getValues(vars,vals);
	model.remove(newObj);
	model.add(oldObj);
	return true;
}
int RF(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30], IloInt partDig, IloInt TVS, IloInt TVF, IloInt partPM, IloInt TS, IloInt TF, IloNum alfa){
//OBS: NESTA IMPLEMENTACAO TS E TVS REPRESENTAM A QUANTIDADE DE ELEMENTOS (PERIODOS, ITENS, VELOCIDADES) QUE FICAM INTEIRAS A CADA ITERACAO 
//     E TF/TVF REPRESENTAM A QUANTIDADE QUE SERA FIXADA
	IloExtractableArray YR(env);
	if(partPM>0){
		for(int i=0; i<N*M*T*S; i++)
			YR.add(IloConversion(env,Y[i],ILOFLOAT));
	}
	IloExtractableArray YvR(env);
	if(partDig>0){
		for(int i=0; i<V*T*S; i++)
			YvR.add(IloConversion(env,Yv[i],ILOFLOAT));
	}

	IloArray< IloIntArray > fixPartY(env);
	IloArray< IloIntArray > intePartY(env);
	IloArray< IloIntArray > fixPartYv(env);
	IloArray< IloIntArray > intePartYv(env);

	switch(partPM){
		case 1://Forward subperiods partition
			subperiodPartY(env,N,M,T,S,TS,TF,intePartY);
			subperiodPartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 2://Forward subperiods + machine partition
			subperiodMachinePartY(env,N,M,T,S,TS,TF,intePartY);
			subperiodMachinePartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 3://Backward subperiods partition
			backSubperiodPartY(env,N,M,T,S,TS,TF,intePartY);
			backSubperiodPartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 4://Backward subperiods + machine partition
			backSubperiodMachinePartY(env,N,M,T,S,TS,TF,intePartY);
			backSubperiodMachinePartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 5://Non-ordered Products partition
			productPartY(env,N,M,T,S,TS,TF,intePartY);
			productPartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 6://Non-ordered Products + machine partition
			productMachinePartY(env,N,M,T,S,TS,TF,intePartY);
			productMachinePartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
		case 7://Ordered Products partition
			orderedProductPartY(env,opl,N,M,T,S,TS,TF,intePartY);
			orderedProductPartY(env,opl,N,M,T,S,TF,TF,fixPartY);
			break;
		case 8://Ordered Products + machine partition
			orderedProductMachinePartY(env,opl,N,M,T,S,TS,TF,intePartY);
			orderedProductMachinePartY(env,opl,N,M,T,S,TF,TF,fixPartY);
			break;
	}

	switch(partDig){
		case 1://Forward subperiods partition
			subperiodPartYv(env,V,T,S,TVS,TVF,intePartYv);
			subperiodPartYv(env,V,T,S,TVF,TVF,fixPartYv);
			break;
		case 2://Forward subperiods partition
			subperiodPartYv(env,V,T,S,TVS,TVF,intePartYv);
			subperiodPartYv(env,V,T,S,TVF,TVF,fixPartYv);
			break;
		case 3://Speed from edges to middle partition
			EdgestoMiddlePartYv(env,V,T,S,TVS,TVF,intePartYv);
			EdgestoMiddlePartYv(env,V,T,S,TVF,TVF,fixPartYv);
			break;
		case 4://Speed from middle to edges partition
			MiddletoEdgesPartYv(env,opl,V,T,S,TVS,TVF,intePartYv);
			MiddletoEdgesPartYv(env,opl,V,T,S,TVF,TVF,fixPartYv);
			break;
		case 5://All variables integralized after paper machines are fixed
			for(int i=0;i<intePartY.getSize();i++){
				intePartYv.add(IloIntArray(env));
				fixPartYv.add(IloIntArray(env));
			}
			subperiodPartYv(env,V,T,S,S*T,1,intePartYv);
			subperiodPartYv(env,V,T,S,S*T,1,fixPartYv);
			break;
	}

	opl.getCplex().readParam(paramName);
	opl.getCplex().setParam(IloCplex::Threads, THREADS);
	opl.getCplex().setParam(IloCplex::TreLim,TRELIM);

	IloNum TL0 = TIS;
	IloNum TL = TL0 - ActTime(opl);
	for(int i=1;i<intePartY.getSize();i++){
		relaxa(opl.getModel(),YR,intePartY[i]);
	}
	for(int i=1;i<intePartYv.getSize();i++){
		relaxa(opl.getModel(),YvR,intePartYv[i]);
	}

	IloInt maxPart = IloMax(intePartY.getSize(),intePartYv.getSize());
#ifdef geraLP
	char nomeLP[256];
#endif
	for(int i=0; i<maxPart-1; i++){
		rootHeur = IloFalse;
		opl.getCplex().setParam(IloCplex::TiLim, IloMin(TL0-ActTime(opl),TL*alfa + TL*(1-alfa)/(maxPart-i)));
		std::cout << "Particao " << i+1 << " de "<< maxPart << std::endl;
		std::cout << "Tempo limite de: " << TL*alfa + TL*(1-alfa)/(maxPart-i) << " segundos!" << std::endl;
		std::cout << "Tempo atual: " << ActTime(opl) << std::endl;
#ifdef geraLP
		if(irand()%100<10){
			sprintf(nomeLP,"RF%d.lp",irand()%200+1);
			cplex.exportModel(nomeLP);
			hasInc = IloFalse;
			return -1;
		}
#endif
		if(!opl.getCplex().solve()){
			std::cout << "Particao infactivel" << std::endl;
			hasInc = IloFalse;
			return -1;
		}
		std::cout << "Tempo atual: " << ActTime(opl) << std::endl;
		std::cout << opl.getCplex().getObjValue() << tab << opl.getCplex().getBestObjValue() << tab << opl.getCplex().getTime() << tab << TL*alfa + TL*(1-alfa)/(maxPart-i) << std::endl;
		TL = TL0 - ActTime(opl);
		opl.getCplex().getValues(Y,incY);
		opl.getCplex().getValues(Yv,incYv);

		std::cout << "Tempo atual: " << ActTime(opl) << std::endl;
		if(i < fixPartY.getSize())
			fixa(Y,incY,fixPartY[i]);
		if(i+1 < intePartY.getSize())
			integra(opl.getModel(),YR,intePartY[i+1]);
		std::cout << "Tempo atual: " << ActTime(opl) << std::endl;
		if(i < fixPartYv.getSize())
			fixa(Yv,incYv,fixPartYv[i]);
		if(i+1 < intePartYv.getSize())
			integra(opl.getModel(),YvR,intePartYv[i+1]);
	}
	TL = TL0 - ActTime(opl);
	opl.getCplex().setParam(IloCplex::TiLim, IloMax(TL,10));
	std::cout << "Particao " << maxPart << " de "<< maxPart << std::endl;
	if(!opl.getCplex().solve()){
		std::cout << "Particao infactivel" << std::endl;
		hasInc = IloFalse;
		return -1;
	}
	std::cout << opl.getCplex().getObjValue() << tab << opl.getCplex().getBestObjValue() << tab << opl.getCplex().getTime() << tab << TL << std::endl;

	hasInc = IloTrue;
	incY.setSize(Y.getSize());
	opl.getCplex().getValues(Y,incY);
	incYv.setSize(Yv.getSize());
	opl.getCplex().getValues(Yv,incYv);
/*
	for(int i=0;i<Y.getSize();i++)
		Y[i].setBounds(0,1);
	for(int i=0;i<Yv.getSize();i++)
		Yv[i].setBounds(0,1);
*/
	return 0;
}
int FO(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, ostream* output, char paramName[30], IloNumArray paramIS){
	IloModel model = opl.getModel();
	IloArray< IloIntArray > PartY(env);
	IloArray< IloIntArray > PartYv(env);
	IloIntArray allVarsY(env);
	IloIntArray allVarsYv(env);

	for(int i=0;i<Y.getSize();i++)
		allVarsY.add(i);
	for(int i=0;i<Yv.getSize();i++)
		allVarsYv.add(i);

	IloNum alfa = paramIS[1];
	IloNum beta = paramIS[2];
	for(int i=0,j=3;i<paramIS[0];i++,j=j+6){
		FOPartY(env,N,M,T,S,(IloInt)paramIS[j],(IloInt)paramIS[j+1],(IloInt)paramIS[j+2],(IloInt)paramIS[j+3],(IloInt)paramIS[j+4],(IloInt)paramIS[j+5],PartY);
	}
#ifdef geraLP
	int lpPart = irand()%PartY.getSize();
	int lpFixed = irand()%2;
	std::cout << "LP generated " << lpFixed << tab << lpPart << std::endl;
#endif

	IloCplex cplex = opl.getCplex();
	cplex.readParam(paramName);
	cplex.setParam(IloCplex::Threads,THREADS);
	cplex.setParam(IloCplex::TreLim,TRELIM);
	IloNum TLFO = TL - ActTime(opl);
	fixa(Y,incY,allVarsY);
	fixa(Yv,incYv,allVarsYv);
	cplex.solve();
	IloNum foOld,foNew;
	foNew = cplex.getObjValue();
	*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
	foOld;
#ifdef geraLP
		char nomeLP[256];
		if(irand()%100>=10){
			hasInc = IloFalse;
			return -1;
		}
		if(lpFixed == 0){
			libera(Y,PartY[lpPart]);
			sprintf(nomeLP,"FO%d.lp",irand()%10);
		}else{
			libera(Yv,allVarsYv);
			libera(Y,PartY[lpPart]);
			sprintf(nomeLP,"FO%d.lp",irand()%10+10);
		}
		cplex.exportModel(nomeLP);
		hasInc = IloFalse;
		return -1;
#endif
	int i = 0;
	do{
		i++;
		std::cout << "Iteracao " << i << std::endl;
		std::cout << "FO old " << foOld << tab << "FO new " << foNew << std::endl;
		foOld = foNew;
		for(int j=0;j<PartY.getSize() && ActTime(opl)<TL;j++){
			libera(Y,PartY[j]);
			cplex.setParam(IloCplex::TiLim,IloMin(TL-ActTime(opl),PartY[j].getSize()/10.0));
#ifdef geraLP
			beta = 0.0;
			if(j == lpPart && lpFixed == 0){
				char nomeLP[256];
				sprintf(nomeLP,"FO%d.lp",irand()%10);
				cplex.exportModel(nomeLP);
				hasInc = IloFalse;
				return -1;
			}
#endif
			if(cplex.solve()){
				if(cplex.getObjValue()<foNew){
					cplex.getValues(Y,incY);
					foNew = cplex.getObjValue();
				}
			}
			TLFO = TL - ActTime(opl);
			std::cout << fixed << setprecision(2) << "Fixed digester " << i << tab << j+1 << "/" << PartY.getSize() << tab << foNew << std::endl;
			*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
			fixa(Y,incY,PartY[j]);
		}
		int k = 0;
		while(foNew>=beta*foOld && k<PartY.getSize() && ActTime(opl)<TL){
			libera(Yv,allVarsYv);
			libera(Y,PartY[k]);
			cplex.setParam(IloCplex::TiLim,IloMin(TL-ActTime(opl),PartY[k].getSize()/10.0+allVarsYv.getSize()/100.0));
#ifdef geraLP
		if(k == lpPart && lpFixed == 1){
			char nomeLP[256];
			sprintf(nomeLP,"FO%d.lp",irand()%10);
			cplex.exportModel(nomeLP);
			hasInc = IloFalse;
			return -1;
		}
#endif
			if(cplex.solve()){
				if(cplex.getObjValue()<foNew){
					cplex.getValues(Y,incY);
					cplex.getValues(Yv,incYv);
					foNew = cplex.getObjValue();
				}
			}
			TLFO = TL - ActTime(opl);
			std::cout << fixed << setprecision(2) << "Released digester " << i << tab << k+1 << "/" << PartY.getSize() << tab << foNew << std::endl;
			*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
			fixa(Y,incY,PartY[k]);
			k++;
		}
		if(k>0)
			fixa(Yv,incYv,allVarsYv);
	}while(alfa*foOld>foNew && ActTime(opl)<TL);
	
	fixa(Y,incY,allVarsY);
	fixa(Yv,incYv,allVarsYv);
	cplex.setParam(IloCplex::TiLim,IloMax(TL-ActTime(opl),10.0));
	cplex.solve();

	*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
	return 0;
}
int FO_OFC(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, ostream* output, char paramName[30], IloNumArray paramIS){
	IloModel model = opl.getModel();
	IloArray< IloIntArray > PartY(env);
	IloArray< IloIntArray > PartYv(env);
	IloIntArray allVarsY(env);
	IloIntArray allVarsYv(env);

	for(int i=0;i<Y.getSize();i++)
		allVarsY.add(i);
	for(int i=0;i<Yv.getSize();i++)
		allVarsYv.add(i);

	IloNum alfa = paramIS[1];
	IloNum beta = paramIS[2];
	for(int i=0,j=3;i<paramIS[0];i++,j=j+6){
		FOPartY(env,N,M,T,S,(IloInt)paramIS[j],(IloInt)paramIS[j+1],(IloInt)paramIS[j+2],(IloInt)paramIS[j+3],(IloInt)paramIS[j+4],(IloInt)paramIS[j+5],PartY);
	}
#ifdef geraLP
	int lpPart = irand()%PartY.getSize();
	int lpFixed = irand()%2;
	std::cout << "LP generated " << lpFixed << tab << lpPart << std::endl;
#endif

	IloNumVarArray deltaI(env,S*T,0,IloInfinity,ILOFLOAT);
	IloNumVarArray I(opl.getElement("Ivirg").asNumVarMap().asNewNumVarArray());
	IloNum ImaxVirg = opl.getElement("Imax_virg").asNum();
	IloNum IminVirg = opl.getElement("Imin_virg").asNum();
	IloNumVar f = opl.getElement("f").asNumVar();
	IloNumVarArray Ns(opl.getElement("Nhour").asNumVarMap().asNewNumVarArray());
	IloNumArray Nbarr(env,Ns.getSize());

	IloExpr montObj(env);
	IloConstraintArray constDeltaI(env);
	for(int s=0;s<S*T;s++){
		montObj += deltaI[s];
		constDeltaI.add(deltaI[s]>=ImaxVirg-I[s]);
		constDeltaI.add(deltaI[s]>=I[s]-IminVirg);
	}
	model.add(constDeltaI);

	IloObjective newObj = IloMinimize(env,montObj);
	IloObjective oldObj = opl.getObjective();

	IloCplex cplex = opl.getCplex();
	cplex.readParam(paramName);
	cplex.setParam(IloCplex::Threads,THREADS);
	cplex.setParam(IloCplex::TreLim,TRELIM);
	//IloNum TLFO = TL - ActTime(opl);
	fixa(Y,incY,allVarsY);
	fixa(Yv,incYv,allVarsYv);
	cplex.solve();
	cplex.getValues(Ns,Nbarr);
	IloNum foOld,foNew;
	foNew = cplex.getObjValue();
	*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
	foOld;
#ifdef geraLP
		char nomeLP[256];
		if(irand()%100>=10){
			hasInc = IloFalse;
			return -1;
		}
		if(lpFixed == 0){
			libera(Y,PartY[lpPart]);
			sprintf(nomeLP,"FO%d.lp",irand()%10);
		}else{
			libera(Yv,allVarsYv);
			libera(Y,PartY[lpPart]);
			sprintf(nomeLP,"FO%d.lp",irand()%10+10);
		}
		cplex.exportModel(nomeLP);
		hasInc = IloFalse;
		return -1;
#endif
	int i = 0;
	bool optSpeed = true;
	do{
topo:
		i++;
		std::cout << "Iteracao " << i << std::endl;
		std::cout << "FO old " << foOld << tab << "FO new " << foNew << std::endl;


		model.remove(oldObj);
		model.add(newObj);
		libera(Yv,allVarsYv);
		for(int s=0;s<Ns.getSize();s++){
			Ns[s].setBounds(Nbarr[s]-Erro,Nbarr[s]+Erro);
		}
		cplex.setParam(IloCplex::TiLim,IloMin(TL-ActTime(opl),allVarsYv.getSize()/50.0));
		if(!cplex.solve() && TL-ActTime(opl)<10){
			model.remove(newObj);
			model.add(oldObj);
			break;
		}
		cplex.getValues(Yv,incYv);
		for(int s=0;s<Ns.getSize();s++){
			Ns[s].setBounds(0,IloInfinity);
		}
		model.remove(newObj);
		model.add(oldObj);
		fixa(Yv,incYv,allVarsYv);
		foOld = foNew;
		for(int j=0;j<PartY.getSize() && ActTime(opl)<TL;j++){
			libera(Y,PartY[j]);
			cplex.setParam(IloCplex::TiLim,IloMin(TL-ActTime(opl),PartY[j].getSize()/10.0));
#ifdef geraLP
			beta = 0.0;
			if(j == lpPart && lpFixed == 0){
				char nomeLP[256];
				sprintf(nomeLP,"FO%d.lp",irand()%10);
				cplex.exportModel(nomeLP);
				hasInc = IloFalse;
				return -1;
			}
#endif
			if(cplex.solve()){
				if(cplex.getObjValue()<foNew){
					cplex.getValues(Y,incY);
					cplex.getValues(Ns,Nbarr);
					foNew = cplex.getObjValue();
					optSpeed = true;
				}
			}else if(!cplex.solve() && TL-ActTime(opl)<10){
				break;
			}
			//TLFO = TL - ActTime(opl);
			std::cout << fixed << setprecision(2) << "Fixed digester " << i << tab << j+1 << "/" << PartY.getSize() << tab << foNew << std::endl;
			*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
			fixa(Y,incY,PartY[j]);
		}
	}while(alfa*foOld>foNew && ActTime(opl)<TL);
	
	fixa(Y,incY,allVarsY);
	fixa(Yv,incYv,allVarsYv);
	model.remove(constDeltaI);
	cplex.setParam(IloCplex::TiLim,TL);
	cplex.solve();

	*output << fixed << setprecision(4) << foNew << tab << ActTime(opl) <<  std::endl;
	return 0;
}
int RF_SP(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloInt partPM, IloInt TS, IloInt TF, IloInt partDig, IloInt TVS, IloInt TVF){
	IloExtractableArray YR(env,N*M*T*S);
	IloExtractableArray YvR(env,V*T*S);
	IloModel model = opl.getModel();
	IloArray< IloIntArray > fixPartY(env);
	IloArray< IloIntArray > intePartY(env);
	IloArray< IloIntArray > fixPartYv(env);
	IloArray< IloIntArray > intePartYv(env);
	IloArray< IloIntVarArray > alfaY(env);

	if(partPM>0){
		for(int i=0; i<N*M*T*S; i++)
			YR[i] = IloConversion(env,Y[i],ILOFLOAT);
		model.add(YR);
	}

	if(partDig>0){
		for(int i=0; i<V*T*S; i++)
			YvR[i] = IloConversion(env,Yv[i],ILOFLOAT);
		model.add(YvR);
	}

	switch(partPM){
		case 1:
			subperiodPartY(env,N,M,T,S,TS,TF,intePartY);
			subperiodPartY(env,N,M,T,S,TF,TF,fixPartY);
			break;
	}

	switch(partDig){
		case 1:
			subperiodPartYv(env,V,T,S,TVS,TVF,intePartYv);
			subperiodPartYv(env,V,T,S,TVF,TVF,fixPartYv);
			break;
	}

	IloCplex cplex = opl.getCplex();
	cplex.setParam(IloCplex::HeurFreq, -1);
	cplex.setParam(IloCplex::RINSHeur, -1);
	cplex.setParam(IloCplex::EachCutLim, 0);
	cplex.setParam(IloCplex::FracCuts, -1);
	//cplex.setParam(IloCplex::EpGap, 0.01);
	cplex.setParam(IloCplex::MIPEmphasis,1);
	cplex.setOut(env.getNullStream());

	IloNum TL0 = TIS;
	IloNum TL = TL0 - ActTime(opl);
	IloNum alfa = 0.2;

	if(partPM>0){
		alfaY.setSize(intePartY.getSize());
		for(IloInt i=0;i<alfaY.getSize();i++)
			alfaY[i] = IloIntVarArray(env);
	}

	if(partPM>0)
		integra(model,YR,intePartY[0]);
	if(partDig>0)
		integra(model,YvR,intePartYv[0]);
	IloInt maxPart = IloMax(intePartY.getSize(),intePartYv.getSize());
	for(int i=0; i<maxPart-1; i++){
		cplex.setParam(IloCplex::TiLim, TL*alfa + TL*(1-alfa)/(maxPart-i));
		//std::cout << "Particao " << i+1 << " de "<< maxPart << std::endl;
		if(!cplex.solve()){
			std::cout << "Particao infactivel" << std::endl;
			hasInc = IloFalse;
			return -1;
		}
		std::cout << i << tab << cplex.getObjValue() << tab << cplex.getBestObjValue() << tab << ActTime(opl) << std::endl;
		TL = TL0 - ActTime(opl);
		IloIntArray interY(env);
		IloIntArray interYv(env);
		IloExpr sumAlfa(env);
		IloArray< IloNumArray > YsolPool(env,cplex.getSolnPoolNsolns());
		for(IloInt n=0;n<cplex.getSolnPoolNsolns();n++){
			alfaY[i].add(IloIntVar(env,0,1));
//			std::cout << alfaY[i][n] << std::endl;
			sumAlfa += alfaY[i][n];
			YsolPool[n] = IloNumArray(env,fixPartY[i].getSize());
			saveSolRel(cplex,Y,YsolPool[n],fixPartY[i],n);
//			std::cout << YsolPool[n] << std::endl;
		}
		model.add(sumAlfa == 1);
//		std::cout << sumAlfa << std::endl;
		IloExpr expr1(env);
		for(IloInt t=0;t<fixPartY[i].getSize();t++){
			expr1.clear();
			for(IloInt n=0;n<YsolPool.getSize();n++){
				expr1 += alfaY[i][n]*YsolPool[n][t];
			}
			model.add(expr1 == Y[fixPartY[i][t]]);
//			std::cout << expr1 << std::endl;
		}

//		getchar();


		if(i+1 < intePartY.getSize())
			integra(model,YR,intePartY[i+1]);
		if(i+1 < intePartYv.getSize())
			integra(model,YvR,intePartYv[i+1]);
	}
	TL = TL0 - ActTime(opl);
	cplex.setParam(IloCplex::TiLim, TL);
	std::cout << "Particao " << maxPart << " de "<< maxPart << std::endl;
	if(!cplex.solve()){
		std::cout << "Particao infactivel" << std::endl;
		hasInc = IloFalse;
		return -1;
	}

	hasInc = IloTrue;
	incY.setSize(Y.getSize());
	cplex.getValues(Y,incY);
	incYv.setSize(Yv.getSize());
	cplex.getValues(Yv,incYv);
	for(int i=0;i<Y.getSize();i++)
		Y[i].setBounds(0,1);
	for(int i=0;i<Yv.getSize();i++)
		Yv[i].setBounds(0,1);

	cplex.setParam(IloCplex::MIPEmphasis,0);
	cplex.setParam(IloCplex::HeurFreq, 0);
	cplex.setParam(IloCplex::RINSHeur, 0);
	cplex.setParam(IloCplex::FracCuts, 0);
	cplex.setParam(IloCplex::EpGap, 1e-4);
	cplex.setParam(IloCplex::EachCutLim, 2100000000);
	return 0;
}
int RF_FP(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloInt part, IloInt TS, IloInt TF){
/*	IloExtractableArray YR(env,N*M*T*S);
	IloExtractableArray YvR(env,V*T*S);
	for(int i=0; i<N*M*T*S; i++)
		YR[i] = IloConversion(env,Y[i],ILOFLOAT);

	for(int i=0; i<V*T*S; i++)
		YvR[i] = IloConversion(env,Yv[i],ILOFLOAT);

	IloModel model = opl.getModel();
	model.add(YR);
	//model.add(YvR);

	IloArray< IloIntArray > fixPartArray(env);
	IloArray< IloIntArray > intePartArray(env);
	switch(part){
		case 1:
			subperiodPartitions(env, N, M, T, S, TS, TF, fixPartArray,intePartArray);
			break;
		case 2:
			subperiodPartitionsBack(env, N, M, T, S, TS, TF, fixPartArray,intePartArray);
			break;
		case 3:
			itemPartitions(env, opl, N, M, T, S, fixPartArray,intePartArray);
			break;
		case 4:
			itemMachinePartitions(env, opl, N, M, T, S, fixPartArray,intePartArray);
			break;
	}
			
	IloCplex cplex = opl.getCplex();
	//cplex.setParam(IloCplex::Threads, 1);
	//cplex.setParam(IloCplex::TiLim, (IloNum)200);
	//cplex.setParam(IloCplex::MIPEmphasis, 1);
	IloNum TL0 = 3600;
	IloNum TL = TL0 - ActTime(opl);
	IloNum alfa = 0.3;
	IloIntVarArray vars(env);
	IloNumArray vals(env);

	integra(model,YR,intePartArray[0]);
	for(int i=0; i<intePartArray.getSize()-1; i++){
		cplex.setParam(IloCplex::TiLim, TL*alfa + TL*(1-alfa)/(intePartArray.getSize()-i));
		std::cout << TL*alfa << tab << TL*(1-alfa)/(intePartArray.getSize()-i) << std::endl; 
		std::cout << "Particao " << i+1 << " de "<< intePartArray.getSize() << std::endl;
		if(!cplex.solve()){
			std::cout << "FS Starting..." << std::endl;
			for(int v=0;v<intePartArray[i].getSize();v++){
				vars.add(Y[intePartArray[i][v]]);
				vals.add(0.0);
			}
			for(int v=0;v<vars.getSize();v++)
				vars[v].setBounds(0,1);
			if(subfeasPump(env,opl,vars,vals))
				for(int v=0;v<vars.getSize();v++)
					if(vals[v] < alfa)
						vars[v].setBounds(0,0);
					else
						vars[v].setBounds(0,0);
			else{
				std::cout << "FS Finished Without Feasible Solution..." << std::endl;
				return -1;
			}
			std::cout << "FS Finished With Feasible Solution..." << std::endl;

		}
		for(int v=0;v<intePartArray[i].getSize();v++){
			vars.add(Y[intePartArray[i][v]]);
			vals.add(cplex.getValue(Y[intePartArray[i][v]]));
		}
		std::cout << TL << tab;
		TL = TL0 - ActTime(opl);
		std::cout << TL << std::endl;
		fixa(env, cplex,Y,fixPartArray[i]);
		integra(model,YR,intePartArray[i+1]);
	}
	TL = TL0 - ActTime(opl);
	std::cout << "Particao " << intePartArray.getSize() << " de "<< intePartArray.getSize() << std::endl;
	if(!cplex.solve()){
		std::cout << "Particao infactivel" << std::endl;
		getchar();
		return -1;
	}

	hasInc = IloTrue;
	incY.setSize(Y.getSize());
	cplex.getValues(Y,incY);
	incYv.setSize(Yv.getSize());
	cplex.getValues(Yv,incYv);
	for(int i=0;i<Y.getSize();i++)
		Y[i].setBounds(0,1);
	for(int i=0;i<Yv.getSize();i++)
		Yv[i].setBounds(0,1);
*/
	return 0;
}
int LP_and_fix(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv){
	
	IloNum alfa = 0.3;
	IloModel model = opl.getModel();
			
	IloCplex cplex = opl.getCplex();
	//cplex.setParam(IloCplex::Threads, 1);
	cplex.setParam(IloCplex::TiLim, (IloNum)200);
	//cplex.setParam(IloCplex::MIPEmphasis, 1);

	opl.convertAllIntVars();
	if(!cplex.solve()){
			std::cout << "Particao infactivel" << std::endl;
			return -1;
	}
	IloNumArray valY(env,Y.getSize());
	cplex.getValues(Y,valY);

	IloNumArray valYv(env,Yv.getSize());
	cplex.getValues(Yv,valYv);

	IloInt contFix = 0;

	for(int i=0; i<Y.getSize(); i++)
		if(valY[i]>(1-alfa)){
			Y[i].setBounds(1,1);
			contFix++;
		}

	for(int i=0; i<Yv.getSize(); i++)
		if(valYv[i]>1-alfa){
			Yv[i].setBounds(1,1);
			contFix++;
		}

	std::cout << "Fixadas: " << contFix << std::endl;
	opl.unconvertAllIntVars();
	if(!cplex.solve()){
			std::cout << "Particao infactivel" << std::endl;
			return -1;
	}
	return 0;
}
int feasPump(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv){
	
	IloModel model = opl.getModel();
	IloCplex cplex = opl.getCplex();
	opl.convertAllIntVars();
	cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
	cplex.setParam(IloCplex::HeurFreq, -1);
	cplex.setParam(IloCplex::RINSHeur, -1);
	cplex.setParam(IloCplex::EachCutLim, 0);
	cplex.setParam(IloCplex::FracCuts, -1);
	cplex.setParam(IloCplex::MIPEmphasis,1);
	if(!cplex.solve()){
			std::cout << "Relaxa��o infactivel" << std::endl;
			hasInc = IloFalse;
			return -1;
	}
	IloNumArray valY(env,Y.getSize());
	cplex.getValues(Y,valY);
	IloNumArray valYv(env,Yv.getSize());
	cplex.getValues(Yv,valYv);
	IloExpr deltaY(env);

	for(int t=1;t<S*T;t++)
		for(int m=0;m<M;m++){
			IloNum imaxVal = 0;
			for(int i=0;i<N;i++)
				if(valY[i*(S*T*M)+t*M+m] > valY[imaxVal])
					imaxVal = i*(S*T*M)+t*M+m;
			for(int i=0;i<imaxVal;i++)
				deltaY += Y[i];
			deltaY += (1 - Y[imaxVal]);
			Y[imaxVal].setBounds(1,1);
			for(int i=imaxVal+1;i<N;i++)
				deltaY += Y[i];
		}

	for(int t=1;t<S*T;t++){
		IloNum vmaxVal = 0;
		for(int v=0;v<V;v++)
			if(valYv[v*(S*T)+t] > valYv[vmaxVal])
				vmaxVal = v*(S*T)+t;
		for(int v=0;v<vmaxVal;v++)
			deltaY += Yv[v];
		deltaY += (1 - Yv[vmaxVal]);
		Yv[vmaxVal].setBounds(1,1);
		for(int v=vmaxVal+1;v<V;v++)
			deltaY += Yv[v];
	}

	cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
	if(!cplex.solve()){
		for(int i=0;i<Y.getSize();i++)
			Y[i].setBounds(0,1);
		for(int i=0;i<Yv.getSize();i++)
			Yv[i].setBounds(0,1);

		IloObjective oldObj = opl.getObjective();
		model.remove(oldObj);
		IloObjective newObj = IloMinimize(env,deltaY);
		model.add(newObj);

		cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
		opl.unconvertAllIntVars();
		if(!cplex.solve()){
			std::cout << "Nao foi possivel encontrar solucao inicial!" << std::endl;
			hasInc = IloFalse;
			return -2;
		}
		hasInc = IloTrue;
		incY.setSize(Y.getSize());
		cplex.getValues(Y,incY);
		incYv.setSize(Yv.getSize());
		cplex.getValues(Yv,incYv);
		model.remove(newObj);
		model.add(oldObj);
	}else{
		hasInc = IloTrue;
		incY.setSize(Y.getSize());
		cplex.getValues(Y,incY);
		incYv.setSize(Yv.getSize());
		cplex.getValues(Yv,incYv);
	}

	cplex.setParam(IloCplex::MIPEmphasis,0);
	cplex.setParam(IloCplex::HeurFreq, 0);
	cplex.setParam(IloCplex::RINSHeur, 0);
	cplex.setParam(IloCplex::FracCuts, 0);
	cplex.setParam(IloCplex::EachCutLim, 2100000000);
	return 0;
}
/*
int FPRL(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv){
	
	IloModel model = opl.getModel();
	IloCplex cplex = opl.getCplex();
	opl.convertAllIntVars();
	cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
	cplex.setParam(IloCplex::HeurFreq, -1);
	cplex.setParam(IloCplex::RINSHeur, -1);
	cplex.setParam(IloCplex::EachCutLim, 0);
	cplex.setParam(IloCplex::FracCuts, -1);
	cplex.setParam(IloCplex::MIPEmphasis,1);
	//cplex.setOut(env.getNullStream());
	if(!cplex.solve()){
			std::cout << "Relaxa��o infactivel" << std::endl;
			hasInc = IloFalse;
			return -1;
	}
	IloNumArray valY(env,Y.getSize());
	cplex.getValues(Y,valY);
	IloNumArray valYv(env,Yv.getSize());
	cplex.getValues(Yv,valYv);
	IloExpr deltaY(env);

	IloNum Speed0 = opl.getElement("speed_Inicial").asNum();
	IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
	IloInt V0 = 0;
	IloInt teta = opl.getElement("teta").asInt();
	IloNumVarArray Ivirg = opl.getElement("Ivirg").asNumVarMap().asNewNumVarArray();
	IloNumVarArray Iliquor = opl.getElement("Iliquor").asNumVarMap().asNewNumVarArray();
	IloNum ImaxLiq = opl.getElement("Imax_virg").asNum();
	IloNum Iavg = (opl.getElement("Imax_virg").asNum() + opl.getElement("Imin_virg").asNum())/2;
	IloNum delta = opl.getElement("delta").asNum();
	IloNum mii = opl.getElement("mii").asNum();
	IloNum cap = opl.getElement("f_heat").asNum();
	for(IloInt v=1;v<=Speeds.getSize();v++)
		if(Speeds.get(v) == Speed0){
			V0 = v-1;
			break;
		}

	IloInt actV = V0;
	IloIntArray fixSpeeds(env,S*T);
	IloBool errorR = IloFalse;


	for(int t=0;t<S*T;t++)
		for(int m=0;m<M;m++){
			IloNum imaxVal = 0;
			for(int i=0;i<N;i++)
				if(valY[i*(S*T*M)+t*M+m] > valY[imaxVal*(S*T*M)+t*M+m])
					imaxVal = i;
			for(int i=0;i<imaxVal;i++)
				deltaY += Y[i*(S*T*M)+t*M+m];
			deltaY += (1 - Y[imaxVal*(S*T*M)+t*M+m]);
			Y[imaxVal*(S*T*M)+t*M+m].setBounds(1,1);
			for(int i=imaxVal+1;i<N;i++)
				deltaY += Y[i*(S*T*M)+t*M+m];
		}

	cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
	if(!cplex.solve()){
		for(int i=0;i<Y.getSize();i++)
			Y[i].setBounds(0,1);
	}else
		deltaY.clear();

	for(int t=0;t<T*S;t++){
		if((cplex.getValue(Ivirg[t]) <= Iavg) && ((Speeds.get(IloMin(actV + teta,V-1))*delta*mii <=cap) || ((cplex.getValue(Iliquor[t]) < 0.9 * ImaxLiq) && (cplex.getValue(Iliquor[S*T-1]) < 0.9 * ImaxLiq))))
			fixSpeeds[t] = IloMin(actV + teta,V-1);
		else
			fixSpeeds[t] = IloMax(actV - teta,0);

		Yv[fixSpeeds[t]*(T*S)+t].setBounds(1,1);
		cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
		if(!cplex.solve()){
			errorR = IloTrue;
			break;
		}
		actV = fixSpeeds[t];
		continue;
	}

	if(errorR){
		for(int i=0;i<Yv.getSize();i++)
			Yv[i].setBounds(0,1);
		cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
		cplex.solve();
		cplex.getValues(Yv,valYv);
		for(int t=1;t<T*S;t++){
			IloNum vmaxVal = 0;
			for(int v=0;v<V;v++)
				if(valYv[v*(T*S)+t] > valYv[vmaxVal])
					vmaxVal = v*(T*S)+t;
			for(int v=0;v<vmaxVal;v++)
				deltaY += Yv[v];
			deltaY += (1 - Yv[vmaxVal]);
			if(abs(vmaxVal - actV) > teta)
				if(vmaxVal > actV)
					actV += teta;
				else
					actV -= teta;
			else
				actV = vmaxVal;
			for(int v=vmaxVal+1;v<V;v++)
				deltaY += Yv[v];
		}
	}

	cplex.getValues(Y,valY);
	cplex.getValues(Yv,valYv);
	cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
	if(!cplex.solve()){
		if(errorR)
			for(int i=0;i<Yv.getSize();i++)
				Yv[i].setBounds(0,1);
		for(int i=0;i<Y.getSize();i++)
			Y[i].setBounds(0,1);

		IloObjective oldObj = opl.getObjective();
		model.remove(oldObj);
		IloObjective newObj = IloMinimize(env,deltaY);
		model.add(newObj);

		cplex.setParam(IloCplex::TiLim, TIS - ActTime(opl));
		opl.unconvertAllIntVars();
		if(!cplex.solve()){
			std::cout << "Nao foi possivel encontrar solucao inicial!" << std::endl;
			hasInc = IloFalse;
			return -2;
		}
		hasInc = IloTrue;
		incY.setSize(Y.getSize());
		cplex.getValues(Y,incY);
		incYv.setSize(Yv.getSize());
		cplex.getValues(Yv,incYv);
		model.remove(newObj);
		model.add(oldObj);
	}else{
		hasInc = IloTrue;
		incY.setSize(Y.getSize());
		cplex.getValues(Y,incY);
		incYv.setSize(Yv.getSize());
		cplex.getValues(Yv,incYv);
		for(int i=0;i<Y.getSize();i++)
			Y[i].setBounds(0,1);
		for(int i=0;i<Yv.getSize();i++)
			Yv[i].setBounds(0,1);
		opl.unconvertAllIntVars();
	}

	cplex.setParam(IloCplex::MIPEmphasis,0);
	cplex.setParam(IloCplex::HeurFreq, 0);
	cplex.setParam(IloCplex::RINSHeur, 0);
	cplex.setParam(IloCplex::FracCuts, 0);
	cplex.setParam(IloCplex::EachCutLim, 2100000000);
	return 0;
}
*/
int FPRL(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, IloNum teta){
	IloModel model = opl.getModel();
	IloCplex cplex = opl.getCplex();
	IloNumMap dem = opl.getElement("d").asNumMap();
	IloNumMap atraso = opl.getElement("Atrasos").asNumMap();
	IloNumMap price = opl.getElement("price").asNumMap();
	IloNumMap b_prod = opl.getElement("b").asNumMap();
	IloNumMap b_virg = opl.getElement("b_virg").asNumMap();
	IloNumMap C = opl.getElement("hour").asNumMap();
	IloNumMap minX = opl.getElement("m_g").asNumMap();
	IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
	IloNum alfa = opl.getElement("alfa").asNum();
	IloNum varD = (opl.getElement("vmax_dig").asNum()-opl.getElement("vmin_dig").asNum())/(V-1);
	hasInc = IloFalse;
	std::vector< std::pair<int,float> > relPrice;
	for(IloInt m=0;m<M;m++)
		for(IloInt i=0;i<N;i++)
			relPrice.push_back(std::pair<int,float>(i*M+m,price.get(i+1)/b_prod[i+1].get(m+1)));
	std::sort(relPrice.begin(),relPrice.end(),pairCompare);
	IloNumArray D(env,N);
	for(IloInt i=0;i<N;i++)
		D[i] = atraso.get(i+1) + dem[i+1].get((IloInt)1);

	//Aloca��o da demanda por maquina e considerando micro-periodos de tamanho igual a Ct/|St|
	IloIntArray AlocPM(env,S*T*M);
	for(IloInt t=0;t<T;t++){
		IloNum Cs = C.get(t+1)/S;
		for(IloInt m=0;m<M;m++){
			for(IloInt s=0;s<S;s++){
				IloBool alocado = IloFalse;
				for(IloInt j=0;j<relPrice.size();j++){
					if(relPrice[j].first%M==m && Cs>Erro){
						IloInt k = relPrice[j].first/M;
						if(D[k]>= teta*Cs / b_prod[k+1].get(m+1)){
							AlocPM[t*S*M+s*M+m] = k;
							D[k] -= Cs / b_prod[k+1].get(m+1);
							alocado = IloTrue;
						}
					}
				}
				if(!alocado){
					IloInt dmax = 0;
					for(int j=1;j<N;j++){
						if(D[dmax]<D[j])
							dmax = j;
					}
					AlocPM[t*S*M+s*M+m] = dmax;
					D[dmax] -= Cs / b_prod[dmax+1].get(m+1);
				}
			}
		}
		for(IloInt i=0;i<N;i++)
			D[i] += dem[i+1].get(t+1);
	}

	IloBool errorV = IloTrue;
	IloIntArray AlocD(env,S*T+1);
	IloInt it = 0;
	while(errorV){
		it++;
		if(it==maxIt){
			std::cout << "Imposible to find feasible solution!" << std::endl;
			hasInc = IloFalse;
			return -1;
		}

		errorV = IloFalse;
		//Reschedule das aloca��es com greedy heuristic
		IloIntArray vetAux(env);
		IloIntArray gramAnt(env,M);
		for(IloInt m=0;m<M;m++)
			gramAnt[m] = opl.getElement("grammage_Inicial").asIntMap().get(m+1)-1;
		IloNumMap sl = opl.getElement("sl").asNumMap();
		for(IloInt t=0;t<T;t++){
			for(IloInt s=0;s<S;s++)
				for(IloInt m=0;m<M;m++)
					vetAux.add(AlocPM[t*S*M+s*M+m]);
			for(IloInt m=0;m<M;m++)
				for(IloInt s=0;s<S;s++){
					IloInt k = 1;
					IloInt iMin = 0;
					IloNum slMin = sl[gramAnt[m]+1][vetAux[iMin]+1].get(m+1);
					while(k<vetAux.getSize()){
						if(sl[gramAnt[m]+1][vetAux[k]+1].get(m+1) < slMin){
							iMin = k;
							slMin = sl[gramAnt[m]+1][vetAux[k]+1].get(m+1);
						}
						k++;
					}
					AlocPM[t*S*M+s*M+m] = vetAux[iMin];
					gramAnt[m] = vetAux[iMin];
					vetAux.remove(iMin);
				}
		}

		IloNum delta = opl.getElement("delta").asNum();
		IloNum zeta = opl.getElement("zeta").asNum();
		IloNum fator = opl.getElement("fator").asNum();
		IloNum fator2 = opl.getElement("fator2").asNum();
		IloNum gama = opl.getElement("gama").asNum();
		IloNum cap = opl.getElement("f_heat").asNum();
		IloNum mii = opl.getElement("mii").asNum();
		IloNum Speed0 = opl.getElement("speed_Inicial").asNum();
		IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
		IloInt V0 = 0;
		for(IloInt v=1;v<=Speeds.getSize();v++)
			if(Speeds.get(v) == Speed0){
				V0 = v-1;
				break;
			}
		IloNumArray Ivirg(env,S*T+1);
		IloNumArray Iliq(env,S*T+1);
		IloNumArray Oliq(env,S*T+1);
		IloNumArray Idry(env,S*T+1);
		IloNumArray Odry(env,S*T+1);
		Ivirg[0] = opl.getElement("I0_virg").asNum();
		Iliq[0] = opl.getElement("I0_liquor").asNum();
		Idry[0] = opl.getElement("I0_dry").asNum();
		IloNum ImaxLiq = opl.getElement("Imax_liquor").asNum();
		IloNum ImaxDry = opl.getElement("Imax_dry").asNum();
		IloNum IminLiq = opl.getElement("Imin_liquor").asNum();
		IloNum IminDry = opl.getElement("Imin_dry").asNum();
	
		for(IloInt s=0;s<=S*T;s++)
			AlocD[s]=V0;
		for(IloInt t=0;t<T*S;t++){
			IloNum Cs = C.get(t/S+1)/S;
			Ivirg[t+1] = Ivirg[t] + Cs * Speed0 * alfa;
			Odry[t+1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
			Iliq[t+1] = Iliq[t] + Cs * Speed0 * delta;
			Oliq[t+1] = min(min(Iliq[t+1]-IminLiq,Cs*mii),(ImaxDry - Idry[t] + Odry[t+1])/gama);
			Iliq[t+1] -= Oliq[t+1];
			Idry[t+1] = Idry[t] + Oliq[t+1]*gama;
			Odry[t+1] = min(Idry[t+1]-IminDry, Odry[t+1]);
			Idry[t+1] -= Odry[t+1];
//			Odry[t+1] = min(min(Idry[t+1]-IminDry,Cs*fator2/fator),Cs*cap/zeta/fator);
			for(IloInt m=0;m<M;m++){
				IloInt k = AlocPM[t*M+m];
				Ivirg[t+1] -= Cs / b_prod[k+1].get(m+1) * b_virg[k+1].get(m+1);
			}
		}

		IloNum IminVirg = opl.getElement("Imin_virg").asNum();
		IloNum ImaxVirg = opl.getElement("Imax_virg").asNum();
		IloInt teta = opl.getElement("teta").asInt();
		IloInt itv = 0;
//		cout << ImaxLiq << tab << IminVirg << tab << ImaxVirg << endl;
		for(IloInt t=1;t<=T*S;t++,itv++){
/*			cout << AlocPM << endl;
			cout << AlocD << endl;
			cout << Ivirg << endl;
			cout << Iliq << endl;
			cout << Oliq << endl;
			cout << Idry << endl;
			cout << Odry << endl;
			getchar();*/
			if(itv>maxIt){
				errorV = true;
				break;
			}
			IloNum Cs = C.get((t-1)/S+1)/S;
			if(Ivirg[t]<IminVirg && Iliq[t]> ImaxLiq){
				errorV = IloTrue;
				break;
			}else if((Ivirg[t] > ImaxVirg && Iliq[t] > ImaxLiq) || (Ivirg[t] > ImaxVirg && Iliq[t] < ImaxLiq) || (Ivirg[t] > IminVirg && Ivirg[t] < ImaxVirg && Iliq[t] > ImaxLiq)){
				IloInt tback = 0;
				for(IloInt taux=t;taux>0;taux--)
					if(AlocD[taux-1]-AlocD[taux]<teta && AlocD[taux]>0){
						tback = taux;
						break;
					}
				if(tback == 0){
					errorV = IloTrue;
					break;
				}
				IloNum cumV = 0;
				for(IloInt t1=tback;t1<=T*S;t1++){
					if(AlocD[t1]>0){
						cumV += varD;
						AlocD[t1]--;
					}
					Ivirg[t1] -= Cs * cumV * alfa;
					Odry[t1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
					Iliq[t1] = Iliq[t1-1] + Cs * Speeds.get(AlocD[t1]+1) * delta;
					Oliq[t1] = min(min(Iliq[t1]-IminLiq,Cs*mii),(ImaxDry - Idry[t1-1] + Odry[t1])/gama);
					Iliq[t1] -= Oliq[t1];
					Idry[t1] = Idry[t1-1] + Oliq[t1]*gama;
					Odry[t1] = min(Idry[t1]-IminDry, Odry[t1]);
					Idry[t1] -= Odry[t1];
				}
				t=tback-1;
			}else if(Ivirg[t] < IminVirg && Iliq[t] < ImaxLiq){
				IloInt tback = 0;
				for(IloInt taux=t;taux>0;taux--)
					if(AlocD[taux]-AlocD[taux-1]<teta  && AlocD[taux]<V-1){
						tback = taux;
						break;
					}
				if(tback == 0){
					errorV = IloTrue;
					break;
				}
				IloNum cumV = 0;
				for(IloInt t1=tback;t1<=T*S;t1++){
					if(AlocD[t1]<V-1){
						cumV += varD;
						AlocD[t1]++;
					}
					Ivirg[t1] += Cs * cumV * alfa;
					Odry[t1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
					Iliq[t1] = Iliq[t1-1] + Cs * Speeds.get(AlocD[t1]+1) * delta;
					Oliq[t1] = min(min(Iliq[t1]-IminLiq,Cs*mii),(ImaxDry - Idry[t1-1] + Odry[t1])/gama);
					Iliq[t1] -= Oliq[t1];
					Idry[t1] = Idry[t1-1] + Oliq[t1]*gama;
					Odry[t1] = min(Idry[t1]-IminDry, Odry[t1]);
					Idry[t1] -= Odry[t1];
				}
				t=tback-1;
			}
		}
/*		cout << it << endl;
		cout << AlocPM << endl;
		cout << AlocD << endl;
		cout << Ivirg << endl;
		cout << Iliq << endl;
		cout << Oliq << endl;
		cout << Idry << endl;
		cout << Odry << endl;
		getchar();*/
		if(!errorV)
			break;

		//Ajuste do sequenciamento da maquina de papel (reducao aleatoria das gramaturas)
		std::vector< std::pair<int,float> > relPulp;
		for(IloInt m=0;m<M;m++)
			for(IloInt i=0;i<N;i++)
				relPulp.push_back(std::pair<int,float>(i*M+m,b_virg[i+1].get(m+1)/b_prod[i+1].get(m+1)));
		std::sort(relPulp.begin(),relPulp.end(),pairCompare);
		IloInt TT = 3;
		for(IloInt i=0;i<N;i++)
			D[i] = atraso.get(i+1);
		for(IloInt t=0;t<T*S;t++){
//			cout << t << tab << it << tab << errorV << tab << T*S << endl;
//			cout << Ivirg << endl;
/*			cout << AlocPM << endl;
			cout << D << endl;
			getchar();*/
			IloNum Cs = C.get(t/S+1)/S;
			if(t%S == 0)
				for(IloInt i=0;i<N;i++)
					D[i] = dem[i+1].get(t/S+1);
			for(IloInt m = 0;m<M;m++)
				D[AlocPM[t*M+m]] -= Cs / b_prod[AlocPM[t*M+m]+1].get(m+1);
			if(Ivirg[t+1] > ImaxVirg){
				for(int tt=0;tt<TT;tt++){
					IloInt t1 = irand()%(t+1);
					IloInt m1 = irand()%M;
					IloInt itFind = 0;
					while(AlocPM[t1*M+m1]==N-1 && itFind<maxItSmall){
						t1 = irand()%(t+1);
						m1 = irand()%M;
						itFind++;
					}
					IloInt gramAtual = AlocPM[t1*M+m1];
					IloInt newgram = N-1;
					IloInt pos = 0;
					for(int i=0;i<relPulp.size();i++)
						if(relPulp[i].first == gramAtual*M+m1){
							pos = i;
							break;
						}
					for(int i=pos-1;i>0;i--){
						IloInt ml = relPulp[i].first%M;
						IloInt il = relPulp[i].first/M;
						if(ml == m1 && D[il]> minX[il+1].get(ml+1)/*Cs / b_prod[il+1].get(m1+1)*/){
							newgram = relPulp[i].first/M;
							break;
						}
					}
//					cout << AlocPM[t1*M+m1] << tab << t1 << tab << m1 << tab << newgram << endl;
					AlocPM[t1*M+m1] = newgram;
					isRand = IloTrue;
					IloNum difCons = (Cs / b_prod[gramAtual+1].get(m1+1) * b_virg[gramAtual+1].get(m1+1)) - (Cs / b_prod[newgram+1].get(m1+1) * b_virg[newgram+1].get(m1+1));
					D[gramAtual] += Cs / b_prod[gramAtual+1].get(m1+1);
					D[newgram] -= Cs / b_prod[newgram+1].get(m1+1);
					for(int t2=t1;t2<T*S;t2++)
						Ivirg[t2+1] += difCons;
				}
				break;
			}else if(Ivirg[t+1] < IminVirg || Iliq[t+1] > ImaxLiq){
				for(int tt=0;tt<TT;tt++){
					IloInt t1 = irand()%(t+1);
					IloInt m1 = irand()%M;
					IloInt itFind = 0;
					while(AlocPM[t1*M+m1]==0 && itFind<maxItSmall){
						t1 = irand()%(t+1);
						m1 = irand()%M;
						itFind++;
					}
					IloInt gramAtual = AlocPM[t1*M+m1];
					IloInt newgram = 0;
					IloInt pos = 0;
					for(int i=0;i<relPulp.size();i++)
						if(relPulp[i].first == gramAtual*M+m1){
							pos = i;
							break;
						}
					for(int i=pos+1;i<relPulp.size();i++){
						IloInt ml = relPulp[i].first%M;
						IloInt il = relPulp[i].first/M;
						if(ml == m1 && D[il]> minX[il+1].get(ml+1)/*Cs / b_prod[il+1].get(m1+1)*/){
							newgram = relPulp[i].first/M;
							break;
						}
					}
//					cout << AlocPM[t1*M+m1] << tab << t1 << tab << m1 << tab << newgram << endl;
					AlocPM[t1*M+m1] = newgram;
					isRand = IloTrue;
					IloNum difCons = (Cs / b_prod[gramAtual+1].get(m1+1) * b_virg[gramAtual+1].get(m1+1)) - (Cs / b_prod[newgram+1].get(m1+1) * b_virg[newgram+1].get(m1+1));
					D[gramAtual] += Cs / b_prod[gramAtual+1].get(m1+1);
					D[newgram] -= Cs / b_prod[newgram+1].get(m1+1);
					for(int t2=t1;t2<T*S;t2++)
						Ivirg[t2+1] += difCons;
				}
				break;
			}
		}
	}


//	cout << AlocD << endl;
//	cout << AlocPM << endl;
	hasInc = IloTrue;
	incY.setSize(Y.getSize());
	incYv.setSize(Yv.getSize());
	for(int t=0;t<T*S;t++){
		for(int i=0;i<N;i++)
			for(int m=0;m<M;m++)
				if(AlocPM[t*M+m] == i)
					incY[i*S*T*M+t*M+m] = 1.0;
				else
					incY[i*S*T*M+t*M+m] = 0.0;
		for(int v=0;v<V;v++)
			if(AlocD[t+1] == v)
				incYv[v*T*S+t] = 1.0;
			else
				incYv[v*T*S+t] = 0.0;
	}
	return 0;
}
int RCH(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30]){
	vector<double> Roleta;
	Roleta.resize(N);
	double soma;
	opl.convertAllIntVars();
	IloCplex cplex = opl.getCplex();
	cplex.readParam(paramName);
	cplex.setParam(IloCplex::TiLim,TIS-ActTime(opl));
	cplex.setParam(IloCplex::Threads,THREADS);
	cplex.setParam(IloCplex::TreLim,TRELIM);
	IloNumVarArray Ns(opl.getElement("Nhour").asNumVarMap().asNewNumVarArray());
	IloNumMap Cap = opl.getElement("hour").asNumMap();
	for(IloInt t=0;t<T;t++){
		IloNum Caps = Cap.get(t+1)/S;
		for(IloInt s=0;s<S;s++)
			Ns[t*S+s].setBounds(Caps-Erro,Caps+Erro);
	}
	cplex.solve();
	IloNumVarArray X(opl.getElement("X").asNumVarMap().asNewNumVarArray());
	IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
	IloNum Speed0 = opl.getElement("speed_Inicial").asNum();
	IloInt V0 = 0;
	for(IloInt v=1;v<=Speeds.getSize();v++){
		if(Speeds.get(v) == Speed0){
			V0 = v-1;
			break;
		}
	}

	incY.setSize(Y.getSize());
	for(int aux=0;aux<incY.getSize();aux++)
		incY[aux]=0.0;
	incYv.setSize(Yv.getSize());
	for(int aux=0;aux<incYv.getSize();aux++)
		incYv[aux]=0.0;

	for(int m=0;m<M;m++){
		for(int s=0;s<S*T;s++){
			soma=0;
			for(int j=0;j<N;j++){
				soma=soma+cplex.getValue(X[j*S*T*M+s*M+m]);
				Roleta[j]=soma;
			}
			for(int j=0;j<N;j++)
				if(soma>Erro)
					Roleta[j]=Roleta[j]/soma*10000;
				else
					Roleta[j]=(j+1)/N*10000;
			int rand=irand()%10000;
			int k=0;
			while(Roleta[k]<rand) k++;
			incY[k*S*T*M+s*M+m]=1.0;
		}
	}
	opl.unconvertAllIntVars();
	for(IloInt s=0;s<S*T;s++)
		Ns[s].setBounds(0,IloInfinity);

	for(int i=0;i<incY.getSize();i++)
		if(incY[i]>0.5)
			Y[i].setBounds(1,1);
		else
			Y[i].setBounds(0,0);

#ifdef geraLP
	cplex.setParam(IloCplex::EpGap,1.0);
#endif
	cplex.setParam(IloCplex::TiLim,TIS-ActTime(opl));
	if(!cplex.solve()){
		for(int i=0;i<incY.getSize();i++)
			Y[i].setBounds(0,1);
		IloObjective oldObj = cplex.getObjective();
		IloExpr newExpr(env);
		for(int i=0;i<incY.getSize();i++)
			if(incY[i]>=0.5)
				newExpr+=1-Y[i];
			else
				newExpr+=Y[i];
		IloObjective newObj = IloMinimize(env,newExpr);
		cplex.getModel().remove(oldObj);
		cplex.getModel().add(newObj);
		if(TIS-ActTime(opl)<1){
			hasInc = IloFalse;
			return -1;
		}
		cplex.setParam(IloCplex::TiLim,TIS-ActTime(opl));
#ifdef geraLP
		char nomeLP[256];
		sprintf(nomeLP,"RCH%d.lp",irand()%10+1);
		cplex.exportModel(nomeLP);
		//hasInc = IloFalse;
		//return -1;
#endif
		if(cplex.solve()){
			cplex.getValues(Yv,incYv);
			cplex.getValues(Y,incY);
			for(int i=0;i<incY.getSize();i++)
				Y[i].setBounds(0,1);
			hasInc = IloTrue;
		}else{
			hasInc = IloFalse;
		}
		cplex.getModel().remove(newObj);
		cplex.getModel().add(oldObj);
	}else{
#ifdef geraLP
		char nomeLP[256];
		sprintf(nomeLP,"RCH%d.lp",irand()%10+11);
		cplex.exportModel(nomeLP);
#endif
		cplex.getValues(Yv,incYv);
		for(int i=0;i<incY.getSize();i++)
			Y[i].setBounds(0,1);
		hasInc = IloTrue;

	}
	return 0;
}
void generateSequence(IloEnv env, IloOplModel opl, IloArray< IloIntArray > Sequences, IloInt l, IloInt M,IloInt N){
	Sequences.clear();
	Sequences.setSize(M);
	IloIntSetMap A(opl.getElement("A").asIntSetMap());
	IloIntMap g0(opl.getElement("grammage_Inicial").asIntMap());
	switch(l){
	case 0://Sobe e depois desce
		for(IloInt m=0;m<M;m++){
			Sequences[m] = IloIntArray(env);
			for(IloInt j=g0.get(m+1)-1;j<N;j++)
				Sequences[m].add(j);
			for(IloInt j=N-2;j>=0;j--)
				Sequences[m].add(j);
			for(IloInt j=1;j<=Sequences[m][0];j++)
				Sequences[m].add(j);
		}
		break;
	case 1://Desce e depois sobe
		for(IloInt m=0;m<M;m++){
			Sequences[m] = IloIntArray(env);
			for(IloInt j=g0.get(m+1)-1;j>=0;j--)
				Sequences[m].add(j);
			for(IloInt j=1;j<N;j++)
				Sequences[m].add(j);
			for(IloInt j=N-2;j>=g0.get(m+1)-1;j--)
				Sequences[m].add(j);
		}
		break;
	case 2://um sobe e o outro desce
		for(IloInt m=0;m<M-1;m++){
			Sequences[m] = IloIntArray(env);
			for(IloInt j=g0.get(m+1)-1;j<N;j++)
				Sequences[m].add(j);
			for(IloInt j=N-2;j>=0;j--)
				Sequences[m].add(j);
			for(IloInt j=1;j<=Sequences[m][0];j++)
				Sequences[m].add(j);
		IloInt m=M-1;
		Sequences[m] = IloIntArray(env);
		for(IloInt j=g0.get(m+1)-1;j>=0;j--)
			Sequences[m].add(j);
		for(IloInt j=1;j<N;j++)
			Sequences[m].add(j);
		for(IloInt j=N-2;j>=g0.get(m+1)-1;j--)
			Sequences[m].add(j);
		}
		break;
	case 3://Depende do conjunto Am
		for(IloInt m=0;m<M;m++){
			Sequences[m] = IloIntArray(env);
			IloIntSet Am = A.get(m+1);
			for(IloInt j=Am.getFirst();j<=Am.getLast();j++)
				Sequences[m].add(j-1);
			for(IloInt j=Am.getLast()-1;j>=Am.getFirst();j--)
				Sequences[m].add(j-1);
		}
		break;
	}
}
void calcDemand(IloEnv env, IloOplModel opl, IloInt pi, IloInt N, IloInt M, IloInt T, IloInt S, IloIntArray Ybar, IloNumArray D){
	IloNumMap Back(opl.getElement("Atrasos").asNumMap());
	IloNumMap d(opl.getElement("d").asNumMap());
	IloNumMap st(opl.getElement("st").asNumMap());
	IloNumMap C(opl.getElement("hour").asNumMap());
	IloIntSetMap Smap(opl.getElement("S").asIntSetMap());
	IloNumMap b(opl.getElement("b").asNumMap());
	IloIntMap g0(opl.getElement("grammage_Inicial").asIntMap());
	IloNumArray prodTime(env,N);

	for(IloInt i=0;i<N;i++){
		prodTime[i] = 0.0;
		D[i]=Back.get(i+1);
		for(IloInt t=0;t<=pi;t++)
			D[i]+=d[i+1].get(t+1);
	}
	for(IloInt t=0;t<=pi;t++){
		IloIntSet St=Smap.get(t+1);
		for(IloInt s=St.getFirst();s<=St.getLast();s++){
			if(s!=1){
				for(IloInt m=0;m<M;m++)
					if(Ybar[(s-1)*M+m]>=0)
						D[Ybar[(s-1)*M+m]]-=(C.get(t+1)/St.getSize()-st[Ybar[(s-2)*M+m]+1][Ybar[(s-1)*M+m]+1].get(m+1)/60)/b[Ybar[(s-1)*M+m]+1].get(m+1);
			}else{
				for(IloInt m=0;m<M;m++){
					if(Ybar[(s-1)*M+m]>=0){
						D[Ybar[(s-1)*M+m]]-=(C.get(t+1)/St.getSize()-st[g0.get(m+1)][Ybar[(s-1)*M+m]+1].get(m+1)/60)/b[Ybar[(s-1)*M+m]+1].get(m+1);
					}
				}
			}
		}
	}
}
int FBCH(IloEnv env, IloOplModel opl, IloInt N, IloInt M, IloInt T, IloInt S, IloInt V, IloIntVarArray Y, IloIntVarArray Yv, char paramName[30], IloNum teta){
	IloNum fstar = IloInfinity;
	IloNum fbar;
	IloArray< IloIntArray > Sequences(env);
	IloInt L;
	IloIntArray AlocPM(env,S*T*M);
	IloNumArray D(env,N);
	IloIntArray K(env,M);
	IloIntSetMap Smap(opl.getElement("S").asIntSetMap());
	IloNumMap C(opl.getElement("hour").asNumMap());
	IloNumMap b(opl.getElement("b").asNumMap());
	IloNumMap dem = opl.getElement("d").asNumMap();
	IloNumMap atraso = opl.getElement("Atrasos").asNumMap();
	IloCplex cplex = opl.getCplex();
	IloIntMap g0 = opl.getElement("grammage_Inicial").asIntMap();
	cplex.readParam(paramName);
	cplex.setParam(IloCplex::Threads,THREADS);
	cplex.setParam(IloCplex::TreLim,TRELIM);
	hasInc = false;
	if(M==1)
		L=0;
	else
		L=3;
	for(IloInt l=0;l<=L;l++){
		for(IloInt i=0;i<AlocPM.getSize();i++)
			AlocPM[i]=-1;
		generateSequence(env,opl,Sequences,l,M,N);
		IloInt n=0;
		for(IloInt m=0;m<M;m++)
			K[m]=0;
		for(IloInt t=0;t<T;t++){
			IloIntSet St=Smap.get(t+1);
			for(IloInt s=St.getFirst();s<=St.getLast();s++){
				for(IloInt m=0;m<M && t+n<T;m++){
					calcDemand(env,opl,t+n,N,M,T,S,AlocPM,D);
					while(AlocPM[(s-1)*M+m]==-1 && t+n<T){
						if((b[Sequences[m][K[m]]+1].get(m+1)*D[Sequences[m][K[m]]]*St.getSize()/C.get(t+1))>=teta){
							AlocPM[(s-1)*M+m]=Sequences[m][K[m]];
						}else{
							if(K[m]==Sequences[m].getSize()-1){
								K[m]=0;
								n++;
								if(n+t<T)
									calcDemand(env,opl,t+n,N,M,T,S,AlocPM,D);
							}else
								K[m]++;
						}
					}
				}
			}
		}
		for(IloInt m=0;m<M;m++)
			if(AlocPM[m]<0)
				AlocPM[m] = g0.get(m+1)-1;
		for(IloInt s=1;s<S*T;s++)
			for(IloInt m=0;m<M;m++)
				if(AlocPM[s*M+m]<0)
					AlocPM[s*M+m]=AlocPM[(s-1)*M+m];
		hasInc = IloFalse;
		IloNumMap sl = opl.getElement("sl").asNumMap();
		IloNumMap b_prod = opl.getElement("b").asNumMap();
		IloNumMap b_virg = opl.getElement("b_virg").asNumMap();
		IloNumMap minX = opl.getElement("m_g").asNumMap();
		IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
		IloNum alfa = opl.getElement("alfa").asNum();
		IloNum varD = (opl.getElement("vmax_dig").asNum()-opl.getElement("vmin_dig").asNum())/(V-1);
		IloBool errorV = IloTrue;
		IloIntArray AlocD(env,S*T+1);
		IloInt it = 0;
		while(errorV){
			it++;
			if(it==maxIt){
				std::cout << "Imposible to find feasible solution!" << std::endl;
				hasInc = IloFalse;
				return -1;
			}

			errorV = IloFalse;
			//Reschedule das aloca��es com greedy heuristic
			IloIntArray vetAux(env);
			IloIntArray gramAnt(env,M);
			for(IloInt m=0;m<M;m++){
				gramAnt[m] = opl.getElement("grammage_Inicial").asIntMap().get(m+1)-1;
			}
			for(IloInt t=0;t<T;t++){
				for(IloInt s=0;s<S;s++){
					for(IloInt m=0;m<M;m++){
						vetAux.add(AlocPM[t*S*M+s*M+m]);
					}
				}
				for(IloInt m=0;m<M;m++){
					for(IloInt s=0;s<S;s++){
						IloInt k = 1;
						IloInt iMin = 0;
						IloNum slMin = sl[gramAnt[m]+1][vetAux[iMin]+1].get(m+1);
						while(k<vetAux.getSize()){
							if(sl[gramAnt[m]+1][vetAux[k]+1].get(m+1) < slMin){
								iMin = k;
								slMin = sl[gramAnt[m]+1][vetAux[k]+1].get(m+1);
							}
							k++;
						}
						AlocPM[t*S*M+s*M+m] = vetAux[iMin];
						gramAnt[m] = vetAux[iMin];
						vetAux.remove(iMin);
					}
				}
			}
			IloNum delta = opl.getElement("delta").asNum();
			IloNum zeta = opl.getElement("zeta").asNum();
			IloNum fator = opl.getElement("fator").asNum();
			IloNum fator2 = opl.getElement("fator2").asNum();
			IloNum gama = opl.getElement("gama").asNum();
			IloNum cap = opl.getElement("f_heat").asNum();
			IloNum mii = opl.getElement("mii").asNum();
			IloNum Speed0 = opl.getElement("speed_Inicial").asNum();
			IloNumMap Speeds = opl.getElement("Speeds").asNumMap();
			IloInt V0 = 0;
			for(IloInt v=1;v<=Speeds.getSize();v++)
				if(Speeds.get(v) == Speed0){
					V0 = v-1;
					break;
				}
			IloNumArray Ivirg(env,S*T+1);
			IloNumArray Iliq(env,S*T+1);
			IloNumArray Oliq(env,S*T+1);
			IloNumArray Idry(env,S*T+1);
			IloNumArray Odry(env,S*T+1);
			Ivirg[0] = opl.getElement("I0_virg").asNum();
			Iliq[0] = opl.getElement("I0_liquor").asNum();
			Idry[0] = opl.getElement("I0_dry").asNum();
			IloNum ImaxLiq = opl.getElement("Imax_liquor").asNum();
			IloNum ImaxDry = opl.getElement("Imax_dry").asNum();
			IloNum IminLiq = opl.getElement("Imin_liquor").asNum();
			IloNum IminDry = opl.getElement("Imin_dry").asNum();
	
			for(IloInt s=0;s<=S*T;s++)
				AlocD[s]=V0;
			for(IloInt t=0;t<T*S;t++){
				IloNum Cs = C.get(t/S+1)/S;
				Ivirg[t+1] = Ivirg[t] + Cs * Speed0 * alfa;
				Odry[t+1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
				Iliq[t+1] = Iliq[t] + Cs * Speed0 * delta;
				Oliq[t+1] = min(min(Iliq[t+1]-IminLiq,Cs*mii),(ImaxDry - Idry[t] + Odry[t+1])/gama);
				Iliq[t+1] -= Oliq[t+1];
				Idry[t+1] = Idry[t] + Oliq[t+1]*gama;
				Odry[t+1] = min(Idry[t+1]-IminDry, Odry[t+1]);
				Idry[t+1] -= Odry[t+1];
	//			Odry[t+1] = min(min(Idry[t+1]-IminDry,Cs*fator2/fator),Cs*cap/zeta/fator);
				for(IloInt m=0;m<M;m++){
					IloInt k = AlocPM[t*M+m];
					Ivirg[t+1] -= Cs / b_prod[k+1].get(m+1) * b_virg[k+1].get(m+1);
				}
			}

			IloNum IminVirg = opl.getElement("Imin_virg").asNum();
			IloNum ImaxVirg = opl.getElement("Imax_virg").asNum();
			IloInt teta = opl.getElement("teta").asInt();
			IloInt itv = 0;
//			cout << ImaxLiq << tab << IminVirg << tab << ImaxVirg << endl;
			for(IloInt t=1;t<=T*S;t++,itv++){
/*				cout << AlocPM << endl;
				cout << AlocD << endl;
				cout << Ivirg << endl;
				cout << Iliq << endl;
				cout << Oliq << endl;
				cout << Idry << endl;
				cout << Odry << endl;
				getchar();*/
				if(itv>maxIt){
					errorV = true;
					break;
				}
				IloNum Cs = C.get((t-1)/S+1)/S;
				if(Ivirg[t]<IminVirg && Iliq[t]> ImaxLiq){
					errorV = IloTrue;
					break;
				}else if((Ivirg[t] > ImaxVirg && Iliq[t] > ImaxLiq) || (Ivirg[t] > ImaxVirg && Iliq[t] < ImaxLiq) || (Ivirg[t] > IminVirg && Ivirg[t] < ImaxVirg && Iliq[t] > ImaxLiq)){
					IloInt tback = 0;
					for(IloInt taux=t;taux>0;taux--)
						if(AlocD[taux-1]-AlocD[taux]<teta && AlocD[taux]>0){
							tback = taux;
							break;
						}
					if(tback == 0){
						errorV = IloTrue;
						break;
					}
					IloNum cumV = 0;
					for(IloInt t1=tback;t1<=T*S;t1++){
						if(AlocD[t1]>0){
							cumV += varD;
							AlocD[t1]--;
						}
						Ivirg[t1] -= Cs * cumV * alfa;
						Odry[t1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
						Iliq[t1] = Iliq[t1-1] + Cs * Speeds.get(AlocD[t1]+1) * delta;
						Oliq[t1] = min(min(Iliq[t1]-IminLiq,Cs*mii),(ImaxDry - Idry[t1-1] + Odry[t1])/gama);
						Iliq[t1] -= Oliq[t1];
						Idry[t1] = Idry[t1-1] + Oliq[t1]*gama;
						Odry[t1] = min(Idry[t1]-IminDry, Odry[t1]);
						Idry[t1] -= Odry[t1];
					}
					t=tback-1;
				}else if(Ivirg[t] < IminVirg && Iliq[t] < ImaxLiq){
					IloInt tback = 0;
					for(IloInt taux=t;taux>0;taux--)
						if(AlocD[taux]-AlocD[taux-1]<teta  && AlocD[taux]<V-1){
							tback = taux;
							break;
						}
					if(tback == 0){
						errorV = IloTrue;
						break;
					}
					IloNum cumV = 0;
					for(IloInt t1=tback;t1<=T*S;t1++){
						if(AlocD[t1]<V-1){
							cumV += varD;
							AlocD[t1]++;
						}
						Ivirg[t1] += Cs * cumV * alfa;
						Odry[t1] = min(Cs*fator2/fator,Cs*cap/zeta/fator);
						Iliq[t1] = Iliq[t1-1] + Cs * Speeds.get(AlocD[t1]+1) * delta;
						Oliq[t1] = min(min(Iliq[t1]-IminLiq,Cs*mii),(ImaxDry - Idry[t1-1] + Odry[t1])/gama);
						Iliq[t1] -= Oliq[t1];
						Idry[t1] = Idry[t1-1] + Oliq[t1]*gama;
						Odry[t1] = min(Idry[t1]-IminDry, Odry[t1]);
						Idry[t1] -= Odry[t1];
					}
					t=tback-1;
				}
			}
	/*		cout << it << endl;
			cout << AlocPM << endl;
			cout << AlocD << endl;
			cout << Ivirg << endl;
			cout << Iliq << endl;
			cout << Oliq << endl;
			cout << Idry << endl;
			cout << Odry << endl;
			getchar();*/
			if(!errorV)
				break;

			//Ajuste do sequenciamento da maquina de papel (reducao aleatoria das gramaturas)
			std::vector< std::pair<int,float> > relPulp;
			for(IloInt m=0;m<M;m++)
				for(IloInt i=0;i<N;i++)
					relPulp.push_back(std::pair<int,float>(i*M+m,b_virg[i+1].get(m+1)/b_prod[i+1].get(m+1)));
			std::sort(relPulp.begin(),relPulp.end(),pairCompare);
			IloInt TT = 3;
			for(IloInt i=0;i<N;i++)
				D[i] = atraso.get(i+1);
			for(IloInt t=0;t<T*S;t++){
	//			cout << t << tab << it << tab << errorV << tab << T*S << endl;
	//			cout << Ivirg << endl;
	/*			cout << AlocPM << endl;
				cout << D << endl;
				getchar();*/
				IloNum Cs = C.get(t/S+1)/S;
				if(t%S == 0)
					for(IloInt i=0;i<N;i++)
						D[i] = dem[i+1].get(t/S+1);
				for(IloInt m = 0;m<M;m++)
					D[AlocPM[t*M+m]] -= Cs / b_prod[AlocPM[t*M+m]+1].get(m+1);
				if(Ivirg[t+1] > ImaxVirg){
					for(int tt=0;tt<TT;tt++){
						IloInt t1 = irand()%(t+1);
						IloInt m1 = irand()%M;
						IloInt itFind = 0;
						while(AlocPM[t1*M+m1]==N-1 && itFind<maxItSmall){
							t1 = irand()%(t+1);
							m1 = irand()%M;
							itFind++;
						}
						IloInt gramAtual = AlocPM[t1*M+m1];
						IloInt newgram = N-1;
						IloInt pos = 0;
						for(int i=0;i<relPulp.size();i++)
							if(relPulp[i].first == gramAtual*M+m1){
								pos = i;
								break;
							}
						for(int i=pos-1;i>0;i--){
							IloInt ml = relPulp[i].first%M;
							IloInt il = relPulp[i].first/M;
							if(ml == m1 && D[il]> minX[il+1].get(ml+1)/*Cs / b_prod[il+1].get(m1+1)*/){
								newgram = relPulp[i].first/M;
								break;
							}
						}
	//					cout << AlocPM[t1*M+m1] << tab << t1 << tab << m1 << tab << newgram << endl;
						AlocPM[t1*M+m1] = newgram;
						isRand = IloTrue;
						IloNum difCons = (Cs / b_prod[gramAtual+1].get(m1+1) * b_virg[gramAtual+1].get(m1+1)) - (Cs / b_prod[newgram+1].get(m1+1) * b_virg[newgram+1].get(m1+1));
						D[gramAtual] += Cs / b_prod[gramAtual+1].get(m1+1);
						D[newgram] -= Cs / b_prod[newgram+1].get(m1+1);
						for(int t2=t1;t2<T*S;t2++)
							Ivirg[t2+1] += difCons;
					}
					break;
				}else if(Ivirg[t+1] < IminVirg || Iliq[t+1] > ImaxLiq){
					for(int tt=0;tt<TT;tt++){
						IloInt t1 = irand()%(t+1);
						IloInt m1 = irand()%M;
						IloInt itFind = 0;
						while(AlocPM[t1*M+m1]==0 && itFind<maxItSmall){
							t1 = irand()%(t+1);
							m1 = irand()%M;
							itFind++;
						}
						IloInt gramAtual = AlocPM[t1*M+m1];
						IloInt newgram = 0;
						IloInt pos = 0;
						for(int i=0;i<relPulp.size();i++)
							if(relPulp[i].first == gramAtual*M+m1){
								pos = i;
								break;
							}
						for(int i=pos+1;i<relPulp.size();i++){
							IloInt ml = relPulp[i].first%M;
							IloInt il = relPulp[i].first/M;
							if(ml == m1 && D[il]> minX[il+1].get(ml+1)/*Cs / b_prod[il+1].get(m1+1)*/){
								newgram = relPulp[i].first/M;
								break;
							}
						}
	//					cout << AlocPM[t1*M+m1] << tab << t1 << tab << m1 << tab << newgram << endl;
						AlocPM[t1*M+m1] = newgram;
						isRand = IloTrue;
						IloNum difCons = (Cs / b_prod[gramAtual+1].get(m1+1) * b_virg[gramAtual+1].get(m1+1)) - (Cs / b_prod[newgram+1].get(m1+1) * b_virg[newgram+1].get(m1+1));
						D[gramAtual] += Cs / b_prod[gramAtual+1].get(m1+1);
						D[newgram] -= Cs / b_prod[newgram+1].get(m1+1);
						for(int t2=t1;t2<T*S;t2++)
							Ivirg[t2+1] += difCons;
					}
					break;
				}
			}
		}
		/*
		fbar = 0.0;
		for(IloInt m=0;m<M;m++){
			fbar += sl[opl.getElement("grammage_Inicial").asIntMap().get(m+1)][AlocPM[m]+1].get(m+1);
			for(IloInt s=1;s<S*T;s++){
				fbar += sl[AlocPM[(s-1)*M+m]+1][AlocPM[s*M+m]+1].get(m+1);
			}
		}
		IloNumArray I(env,N);
		for(IloInt s=0;s<S*T;s++)
		//Salvar a solu��o melhor
		*/
		for(IloInt i=0,aux=0;i<N;i++){
			for(IloInt s=0;s<S*T;s++){
				for(IloInt m=0;m<M;m++,aux++){
					if(AlocPM[s*M+m]==i)
						Y[aux].setBounds(1,1);
					else
						Y[aux].setBounds(0,0);
				}
			}
		}
		for(IloInt v=0,aux=0;v<V;v++){
			for(IloInt s=0;s<S*T;s++,aux++){
				if(AlocD[s+1]==v)
					Yv[aux].setBounds(1,1);
				else
					Yv[aux].setBounds(0,0);
			}
		}
#ifdef geraLP
		char nomeLP[256];
		if(irand()%100<10){
			sprintf(nomeLP,"FBCH%d.lp",irand()%20);
			cplex.exportModel(nomeLP);
			hasInc = IloFalse;
			return -1;
		}
#endif
		cplex.setParam(IloCplex::TiLim,TIS-ActTime(opl));
		if(cplex.solve()){
			hasInc = IloTrue;
			fbar = cplex.getObjValue();
			if(fbar < fstar){
				fstar = fbar;
				cplex.getValues(Y,incY);
				cplex.getValues(Yv,incYv);
			}
		}


	}
	for(int i=0;i<Y.getSize();i++)
		Y[i].setBounds(0,1);
	for(int i=0;i<Yv.getSize();i++)
		Yv[i].setBounds(0,1);
	return 0;
}
int LP(IloOplModel opl){
	IloCplex cplex = opl.getCplex();
	IloModel model = opl.getModel();
	opl.convertAllIntVars();
	cplex.setParam(IloCplex::Threads,THREADS);
	cplex.setParam(IloCplex::TreLim,TRELIM);
		if(!cplex.solve()){
			std::cout << "Relaxacao infactivel" << std::endl;
			return -1;
	}
	hasInc = IloTrue;
	return 0;
}
int main(int argc, char* argv[]){

	IloEnv env;
	IloInt status;

	if(argc < 15){
		cerr << "Numero de argumentos invalidos!";
		return -1;
	}

	irand.seed(atoi(argv[14]));
	fstream outFO(argv[3],fstream::ios_base::out | fstream::ios_base::app);
	fstream outSol(argv[4],fstream::ios_base::out | fstream::ios_base::trunc);
	fstream outComp(argv[5],fstream::ios_base::out | fstream::ios_base::trunc);

	try{

		int ISoption = atoi(argv[10]);//Initial Solution Option
		int ImpOption = atoi(argv[11]);//Improvement Heuristic
		TIS = atoi(argv[12]);
		TL = atoi(argv[13]);
		IloOplRunConfiguration rc(env,argv[1],argv[2]);
		IloOplModel opl = rc.getOplModel();
	
		opl.generate();
		THREADS = atoi(argv[8]);
		TRELIM = atoi(argv[9]);

		int argi = 15;
		bool argType = false;
		IloNumArray paramIS(env);
		IloNumArray paramImp(env);
		char* ISOpt = argv[6];
		char* ImpOpt = argv[7];

		while(argi<argc){
			if(argv[argi][0] != '-'){
				if(argType == false){
					paramIS.add((IloNum)atof(argv[argi]));
				}else{
					paramImp.add((IloNum)atof(argv[argi]));
				}
				argi++;
			}else{
				switch(argv[argi][1]){
				case 'c':
					argType = false;
					break;
				case 'i':
					argType = true;
					break;
				}
				argi++;
			}
		}

		IloIntVarArray Y(opl.getElement("Y").asIntVarMap().asNewIntVarArray());
		IloIntVarArray Yv(opl.getElement("Yv").asIntVarMap().asNewIntVarArray());
		IloInt T = opl.getElement("NPeriods").asInt();
		IloInt S = opl.getElement("NSubPeriods").asInt();
		IloInt M = opl.getElement("NPMachines").asInt();
		IloInt N = opl.getElement("NGrammage").asInt();
		IloInt V = opl.getElement("NSpeed").asInt();
		IloIntSetMap SMap(opl.getElement("S").asIntSetMap());
		IloNumVarMap Ns(opl.getElement("Nhour").asNumVarMap());
		//opl.getCplex().setOut(env.getNullStream());
		//opl.getCplex().setWarning(env.getNullStream());
		opl.getCplex().setParam(IloCplex::ClockType,2);

		incY = IloNumArray(env);		
		incYv = IloNumArray(env);

		bool isRelax = false;
		hasInc = IloFalse;

		startTimer(opl);
		std::cout << "Solucao inicial: ";
		switch(ISoption){//Initial solution options agrv[6]
			case 1: //Linear relaxation of the problem
				std::cout << "Relaxacao linear" << std::endl;
				status = LP(opl);
				isRelax = true;
				break;
			case 2:
				std::cout << "Heuristica construtiva gulosa (FPRL)" << std::endl;
				if(paramIS.getSize() < 1){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}
				status = FPRL(env, opl, N, M, T, S, V, Y, Yv, paramIS[0]);//Greed heuristic with feasibility pump based heuristic to treat infeasibilities
				break;
			case 3:
				std::cout << "Heuristica baseada em arredondamento (RCH)" << std::endl;
				status = RCH(env, opl, N, M, T, S, V, Y, Yv, ISOpt);//Round heuristic - different from the paper
				break;
			case 4:
				std::cout << "Heuristica baseada em figueira et al (2013) (FBCH)" << std::endl;
				if(paramIS.getSize() < 1){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}
				status = FBCH(env, opl, N, M, T, S, V, Y, Yv, ISOpt, paramIS[0]);//Construtive heuristic based on the proposed by Figueira et al. (2013)
				break;
			case 5:
				std::cout << "Heuristica relax-and-fix" << std::endl;
				if(paramIS.getSize() < 7){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}
				status = RF(env, opl, N, M, T, S, V, Y, Yv, ISOpt, paramIS[0], paramIS[1], paramIS[2], paramIS[3], paramIS[4], paramIS[5], paramIS[6]);
				break;
			case 99://Generate LP of the problem with random ID
				std::cout << "Gerando LP" << std::endl;
				char nomeLP[256];
				sprintf(nomeLP,"saida%d.lp",irand()%20+1);
				opl.getCplex().exportModel(nomeLP);
				return 0;
				break;
			default:
				std::cout << "Sem solucao inicial" << std::endl;
				break;
		}

		std::cout << "Tempo solucao inicial: " << ActTime(opl) << std::endl; 
		std::cout << "Tempo restante: " << TL - ActTime(opl) << std::endl; 
		std::cout << "M�todo de melhoria: ";
		switch(ImpOption){
		default:
			if(hasInc){
				std::cout << "Resolver problema fixado!" << std::endl; 
				//cout << incY << endl;
				//cout << incYv << endl;
				//opl.getCplex().setParam(IloCplex::TiLim, TL - ActTime(opl));
				for(int i=0;i<incY.getSize();i++)
					if(incY[i]>0.5)
						Y[i].setBounds(1,1);
					else
						Y[i].setBounds(0,0);
				for(int i=0;i<incYv.getSize();i++)
					if(incYv[i]>0.5)
						Yv[i].setBounds(1,1);
					else
						Yv[i].setBounds(0,0);
				opl.getCplex().add(printCallback(env,&outComp));
				opl.getCplex().readParam(ImpOpt);
				if(opl.getCplex().solve())
					hasInc = IloTrue;
				else
					hasInc = IloFalse;
			}else if(ISoption==0){
				std::cout << "Primeira solu��o do CPLEX!" << std::endl; 
				opl.getCplex().add(printCallback(env,&outComp));
				opl.getCplex().readParam(ImpOpt);
				opl.getCplex().setParam(IloCplex::TiLim, TL - ActTime(opl));
				opl.getCplex().setParam(IloCplex::EpGap,1.0);
				if(opl.getCplex().solve())
					hasInc = IloTrue;
				else
					hasInc = IloFalse;
			}
			break;
		case 2:
			if(hasInc){
				std::cout << "MIP Started!" << std::endl; 
				IloNumVarArray vars(env);
				vars.add(Y.toNumVarArray());
				vars.add(Yv.toNumVarArray());
				for(int aux=0;aux<vars.getSize();aux++)
					vars[aux].setBounds(0,1);
				IloNumArray vals(env);
				vals.add(incY);
				vals.add(incYv);
				if(opl.getCplex().getNMIPStarts()>0)
					opl.getCplex().deleteMIPStarts(0,opl.getCplex().getNMIPStarts());
				opl.getCplex().addMIPStart(vars,vals);
			}
			opl.getCplex().add(printCallback(env,&outComp));
            opl.getCplex().readParam(ImpOpt);
            opl.getCplex().setParam(IloCplex::TiLim, TL - ActTime(opl));
            opl.getCplex().setParam(IloCplex::Threads,THREADS);
			opl.getCplex().setParam(IloCplex::TreLim,TRELIM);
			if(opl.getCplex().solve())
				hasInc = IloTrue;
			else{
				hasInc = IloFalse;
				status = -1;
			}
			break;
		case 3:
			if(hasInc && TL-ActTime(opl)>10){
				std::cout << "Fix-and-optimize tradicional" << std::endl; 
				if(paramImp.getSize() < 1){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}
				if(paramImp.getSize() < paramImp[0]*6+3){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}

				FO(env, opl, N, M, T, S, V, Y, Yv, &outComp, ImpOpt, paramImp);
			}
			break;
		case 4:
			if(hasInc && TL-ActTime(opl)>10){
				std::cout << "Fix-and-optimize OFC" << std::endl; 
				if(paramImp.getSize() < 1){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}
				if(paramImp.getSize() < paramImp[0]*6+3){
					std::cout << "Numero de parametros do metodo de solucao inicial invalido!" << std::endl;
					goto codeEnd;
				}

				FO_OFC(env, opl, N, M, T, S, V, Y, Yv, &outComp, ImpOpt, paramImp);
			}
			break;
		case 0:
			goto codeEnd;
		}
		
		if(status<0 || !hasInc){
			outFO << IloInfinity << tab << opl.getCplex().getBestObjValue() << tab << ActTime(opl) << tab << opl.getCplex().getNnodes();
			if(isRand)
				outFO << tab << "R";
			outFO << std::endl;
			outSol << "Infeasible solution!" << std::endl;
		}


		if(hasInc || isRelax)
			printSolution(&outFO,&outSol,opl,isRelax);

	}catch(IloException& e){
	cout<<"Exce��o capturada pelo Concert: "<<e<<endl;
	outFO<<"Exce��o capturada pelo Concert: "<<e<<endl;
	}catch(...){
	cout<<"Erro de origem desconhecida"<<endl;
	outFO<<"Erro de origem desconhecida"<<endl;
	}
codeEnd:
	getchar();
	return status;
}
